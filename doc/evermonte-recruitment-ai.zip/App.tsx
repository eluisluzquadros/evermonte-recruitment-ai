import React, { useState, useEffect } from 'react';
import { HashRouter, Routes, Route, NavLink, Navigate } from 'react-router-dom';
import { LayoutDashboard, Users, FileText, Target, Briefcase, Kanban, LogIn, LogOut, Presentation } from 'lucide-react';

import Phase1Alignment from './components/Phase1Alignment';
import Phase2Interview from './components/Phase2Interview';
import Phase3Shortlist from './components/Phase3Shortlist';
import Phase4Decision from './components/Phase4Decision';
import DashboardKanban from './components/DashboardKanban';
import ClientReport from './components/ClientReport';
import GlobalChatAssistant from './components/GlobalChatAssistant';
import { Phase3Result, Phase2Result, Phase1Result, Phase4Result } from './types';
import { initGoogleAuth, signInWithGoogle, signOut, getUserProfile, isAuthenticated } from './services/authService';

// Simple mock database for the session
interface AppState {
    phase1Data: Phase1Result | null;
    candidates: {
        name: string;
        cvText: string;
        interviewReport: string;
        fullPhase2: Phase2Result; // Store the full object
    }[];
    shortlist: Phase3Result[];
    phase4Result: Phase4Result | null;
}

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>({
      phase1Data: null,
      candidates: [],
      shortlist: [],
      phase4Result: null
  });

  const [user, setUser] = useState<{ name: string, email: string, picture: string } | null>(null);

  useEffect(() => {
      // Initialize Google Auth on mount
      initGoogleAuth();
  }, []);

  const handleLogin = async () => {
      try {
          await signInWithGoogle();
          const profile = getUserProfile();
          if (profile) setUser(profile);
      } catch (error) {
          console.error("Login failed", error);
          alert("Falha no login com Google.");
      }
  };

  const handleLogout = () => {
      signOut();
      setUser(null);
  };

  const setPhase1Data = (data: Phase1Result) => {
      setAppState(prev => ({ ...prev, phase1Data: data }));
  };

  const addCandidateEvaluation = (evaluation: Phase2Result, cvText: string, reportText: string) => {
      setAppState(prev => ({
          ...prev,
          candidates: [...prev.candidates, {
              name: evaluation.candidateName,
              cvText,
              interviewReport: reportText,
              fullPhase2: evaluation
          }]
      }));
  };

  const setShortlist = (list: Phase3Result[]) => {
      setAppState(prev => ({
          ...prev,
          shortlist: list
      }));
  };

  const setPhase4Result = (result: Phase4Result) => {
      setAppState(prev => ({
          ...prev,
          phase4Result: result
      }));
  };

  return (
    <HashRouter>
      <div className="flex h-screen w-full bg-gray-50 overflow-hidden font-sans">
        {/* Sidebar - Fixed width, independent scroll */}
        <aside className="w-64 bg-slate-900 text-slate-300 flex flex-col flex-shrink-0 border-r border-slate-800">
            <div className="p-6 border-b border-slate-800 flex-shrink-0">
                <h1 className="text-xl font-bold text-white flex items-center gap-2">
                    <Briefcase className="text-blue-500" />
                    Evermonte AI
                </h1>
                <p className="text-xs text-slate-500 mt-1">Recruitment OS</p>
            </div>

            <div className="p-4 border-b border-slate-800">
                {user ? (
                    <div className="flex items-center gap-3 mb-2">
                        <img src={user.picture} alt="User" className="w-8 h-8 rounded-full border border-slate-600" />
                        <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-white truncate">{user.name}</p>
                            <p className="text-xs text-slate-500 truncate">{user.email}</p>
                        </div>
                        <button onClick={handleLogout} className="text-slate-500 hover:text-red-400">
                            <LogOut className="w-4 h-4" />
                        </button>
                    </div>
                ) : (
                    <button 
                        onClick={handleLogin}
                        className="w-full bg-slate-800 hover:bg-slate-700 text-white text-sm py-2 px-3 rounded-lg flex items-center justify-center gap-2 transition-colors"
                    >
                        <LogIn className="w-4 h-4" />
                        Login Google Workspace
                    </button>
                )}
            </div>

            <nav className="flex-1 p-4 space-y-2 overflow-y-auto">
                <NavLink to="/dashboard" className={({isActive}) => `flex items-center p-3 rounded-lg transition-all ${isActive ? 'bg-indigo-600 text-white shadow-lg' : 'hover:bg-slate-800'}`}>
                    <Kanban className="w-5 h-5 mr-3 flex-shrink-0" />
                    Dashboard
                </NavLink>

                <div className="pt-4 pb-2 pl-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Processo Seletivo
                </div>

                <NavLink to="/phase1" className={({isActive}) => `flex items-center p-3 rounded-lg transition-all ${isActive ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-slate-800'}`}>
                    <LayoutDashboard className="w-5 h-5 mr-3 flex-shrink-0" />
                    Fase 1: Alinhamento
                    {appState.phase1Data && <span className="ml-auto text-green-400 text-xs">✓</span>}
                </NavLink>
                <NavLink to="/phase2" className={({isActive}) => `flex items-center p-3 rounded-lg transition-all ${isActive ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-slate-800'}`}>
                    <Users className="w-5 h-5 mr-3 flex-shrink-0" />
                    Fase 2: Entrevistas
                    <span className="ml-auto bg-slate-700 text-xs px-2 py-0.5 rounded-full">{appState.candidates.length}</span>
                </NavLink>
                <NavLink to="/phase3" className={({isActive}) => `flex items-center p-3 rounded-lg transition-all ${isActive ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-slate-800'}`}>
                    <FileText className="w-5 h-5 mr-3 flex-shrink-0" />
                    Fase 3: Shortlist
                    {appState.shortlist.length > 0 && <span className="ml-auto bg-slate-700 text-xs px-2 py-0.5 rounded-full">{appState.shortlist.length}</span>}
                </NavLink>
                <NavLink to="/phase4" className={({isActive}) => `flex items-center p-3 rounded-lg transition-all ${isActive ? 'bg-blue-600 text-white shadow-lg' : 'hover:bg-slate-800'}`}>
                    <Target className="w-5 h-5 mr-3 flex-shrink-0" />
                    Fase 4: Decisão
                    {appState.phase4Result && <span className="ml-auto text-green-400 text-xs">✓</span>}
                </NavLink>

                <div className="pt-4 pb-2 pl-3 text-xs font-semibold text-slate-500 uppercase tracking-wider">
                    Apresentação
                </div>
                
                <NavLink to="/report" className={({isActive}) => `flex items-center p-3 rounded-lg transition-all ${isActive ? 'bg-emerald-600 text-white shadow-lg' : 'hover:bg-slate-800'}`}>
                    <Presentation className="w-5 h-5 mr-3 flex-shrink-0" />
                    Visão do Cliente
                </NavLink>
            </nav>

            <div className="p-4 text-xs text-slate-600 text-center border-t border-slate-800 flex-shrink-0">
                Automated by Gemini 3.0 Pro
            </div>
        </aside>

        {/* Main Content - Independent scroll */}
        <main className="flex-1 overflow-y-auto min-w-0 relative bg-gray-50">
            <Routes>
                <Route path="/" element={<Navigate to="/dashboard" replace />} />
                <Route 
                    path="/dashboard" 
                    element={<DashboardKanban 
                        candidates={appState.candidates}
                        shortlist={appState.shortlist}
                        phase4Result={appState.phase4Result}
                        phase1Data={appState.phase1Data}
                    />} 
                />
                <Route 
                    path="/phase1" 
                    element={<div className="p-4 md:p-8"><Phase1Alignment onComplete={setPhase1Data} savedData={appState.phase1Data} /></div>} 
                />
                <Route 
                    path="/phase2" 
                    element={<div className="p-4 md:p-8"><Phase2Interview onCandidateEvaluated={addCandidateEvaluation} /></div>} 
                />
                <Route 
                    path="/phase3" 
                    element={<div className="p-4 md:p-8"><Phase3Shortlist candidates={appState.candidates} onShortlistFinalized={setShortlist} /></div>} 
                />
                <Route 
                    path="/phase4" 
                    element={<div className="p-4 md:p-8"><Phase4Decision 
                        shortlist={appState.shortlist} 
                        phase1Data={appState.phase1Data}
                        phase2Data={appState.candidates.map(c => c.fullPhase2)}
                        onDecisionGenerated={setPhase4Result}
                        savedResult={appState.phase4Result}
                    /></div>} 
                />
                <Route 
                    path="/report" 
                    element={<ClientReport 
                        phase1={appState.phase1Data}
                        candidates={appState.candidates}
                        shortlist={appState.shortlist}
                    />} 
                />
            </Routes>
            
            {/* Global Chat Assistant rendered over content */}
            <GlobalChatAssistant appState={appState} />
        </main>
      </div>
    </HashRouter>
  );
};

export default App;