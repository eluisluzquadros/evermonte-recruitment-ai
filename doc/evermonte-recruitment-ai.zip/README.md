# Evermonte Recruitment AI

**Recruitment OS Powered by Gemini 3.0 Pro**

Plataforma de inteligência artificial desenvolvida para centralizar, automatizar e elevar o nível estratégico do processo de recrutamento e seleção da Evermonte. O sistema utiliza o estado da arte em IA Generativa para auxiliar consultores desde o alinhamento cultural até a tomada de decisão executiva, totalmente integrado ao Google Workspace.

---

## 🧠 Strategic Cognitive Audit (WEF 2025 Framework)

Baseado no relatório "Future of Jobs 2025" do Fórum Econômico Mundial, a plataforma foi desenhada para potencializar as capacidades humanas críticas:

### 1. Analytical Thinking (Pensamento Analítico)
*   **Feature:** Dashboard Kanban com Insights Proativos.
*   **Capacidade:** O sistema não apenas armazena dados, mas cruza informações da Fase 1 (Cultura) com a Fase 2 (Candidatos) para identificar riscos de *cultural fit*, discrepâncias salariais e destaques do pipeline automaticamente.

### 2. Creative Thinking (Pensamento Criativo)
*   **Feature:** Evermonte AI Assistant (RAG Contextual).
*   **Capacidade:** Um "Shadow Recruiter" disponível 24/7. O recrutador pode dialogar com os dados: *"Compare o perfil de liderança do Candidato A com o Candidato B baseado nos relatórios Cognisess"* ou *"Sugira perguntas para a entrevista final baseadas nas fraquezas identificadas"*.

### 3. Critical Thinking (Pensamento Crítico)
*   **Feature:** Human-in-the-Loop (Fase 2 e 3).
*   **Capacidade:** A IA extrai e sugere, mas o consultor valida. A interface de edição na Fase 2 garante que a "verdade" inserida no sistema seja precisa, eliminando alucinações antes da consolidação.

### 4. Resilience, Flexibility & Agility
*   **Feature:** Integração Google Workspace & Leitura Universal.
*   **Capacidade:** O sistema aceita input de qualquer lugar: texto colado, PDF/DOCX arrastado, importação direta do Google Drive ou busca de transcrições no Gmail.

### 5. Systems Thinking (Consciência Tecnológica)
*   **Feature:** Arquitetura Modular & Segurança.
*   **Capacidade:** Autenticação OAuth2 robusta com Google, garantindo segurança no acesso aos dados e documentos confidenciais.

---

## 🚀 Transformation Roadmap (Plano de Ação)

### Status: Fase 2 - Integração & Inteligência (Concluído ✅)
1.  **Human-in-the-Loop:** Interfaces de edição e validação na Fase 2.
2.  **Google Workspace Integration:** Login Unificado (SSO), Drive Picker e Gmail Picker.
3.  **AI Brain Upgrade:** Migração para `gemini-3-pro-preview` e implementação de RAG no Chatbot.
4.  **Dashboard Proativo:** Kanban com análise de riscos em tempo real.

### Próximo Sprint: Fase 3 - Dados & Escala (Em Planejamento 🚧)

#### 1. Batch Particle Accelerator (Processamento em Lote)
*   **Objetivo:** Permitir o upload de 10, 20 ou 50 currículos simultaneamente na Fase 2.
*   **Implementação:** Criar uma fila de processamento assíncrona que gerencia os limites de taxa da API do Gemini, processando candidatos em background enquanto o recrutador valida os primeiros resultados.

#### 2. Zero Gravity Data (Persistência & Portabilidade)
*   **Objetivo:** Garantir que nenhum dado seja perdido ao fechar o navegador.
*   **Implementação:** 
    *   Auto-save robusto no `localStorage` / `IndexedDB`.
    *   Sistema de **Backup Completo (JSON)**: Exportar e Importar o estado inteiro da aplicação (todas as fases) para compartilhar entre consultores.

#### 3. Business Intelligence Export
*   **Objetivo:** Conectar os dados do recrutamento com ferramentas de BI (PowerBI, Looker, Tableau).
*   **Implementação:** Gerador de arquivos Excel (.xlsx) estruturados, contendo abas separadas para "Dados Consolidados", "Métricas de Funil" e "Detalhes dos Candidatos", prontos para importação.

---

## 🌟 Principais Funcionalidades Atuais

### 📊 Dashboard Kanban & Insights
*   **Visão de Funil:** Acompanhe candidatos movendo-se de *Entrevistados* -> *Shortlist* -> *Decisão*.
*   **IA Proativa:** Cards de alerta automáticos ("Risco Cultural Detectado", "Budget Excedido").
*   **Métricas:** Taxas de conversão e contagem em tempo real.

### 🤖 Evermonte AI Assistant
*   **Contexto Global:** O chat sabe tudo. Ele lê Alinhamento, Entrevistas, Shortlist e Decisões.
*   **Consultoria:** Funciona como um par sênior para discutir estratégias de contratação.

### 📄 Relatórios Executivos (Fase 4)
*   **Integração Cognisess:** A Fase 4 agora ingere relatórios técnicos (Lens Mini, Competência, Liderança) para gerar uma análise comportamental profunda.
*   **Narrativa de Venda:** Gera "Cenários de Decisão" focados em benefícios para o cliente.

---

## 🛠️ Stack Tecnológico

*   **Frontend:** React 19, React Router v7
*   **Estilização:** Tailwind CSS, Lucide React
*   **AI Core:** Google GenAI SDK (`gemini-3-pro-preview`)
*   **Integrações:** Google Identity Services (OAuth2), Google Drive API v3, Gmail API v1.
*   **Processamento de Arquivos:** `pdf.js` (PDF), `mammoth.js` (DOCX), `xlsx` (Excel Export).

---

## 📦 Instalação e Configuração

### Pré-requisitos
*   Node.js (v18+)
*   Chave de API do Google Gemini (AI Studio)
*   Google Cloud Project (para OAuth2)

### Passos

1.  **Instale as dependências:**
    ```bash
    npm install
    ```

2.  **Configure as Variáveis de Ambiente:**
    Crie um arquivo `.env` na raiz:
    ```env
    # Obrigatório para inteligência
    API_KEY=sua_chave_do_google_ai_studio
    
    # Obrigatório para Login, Drive e Gmail
    GOOGLE_CLIENT_ID=seu_client_id_do_google_cloud
    ```

3.  **Execute o projeto:**
    ```bash
    npm start
    ```

---

Developed for **Evermonte Executive Search**