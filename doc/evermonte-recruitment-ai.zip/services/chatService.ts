import { GoogleGenAI, Chat, Content } from "@google/genai";
import { Phase1Result, Phase2Result, Phase3Result, Phase4Result } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export interface ChatMessage {
  role: 'user' | 'model';
  text: string;
}

export const createChatSession = (
  phase1: Phase1Result | null,
  phase2: { name: string; fullPhase2: Phase2Result }[],
  phase3: Phase3Result[],
  phase4: Phase4Result | null,
  history: Content[] = []
): Chat => {
  const modelId = "gemini-3-pro-preview";

  // Serialize the current state of the application into a readable context context
  const contextData = `
    === DADOS ATUAIS DO PROCESSO SELETIVO (SESSÃO ATUAL - LIVE UPDATE) ===
    
    [FASE 1 - ALINHAMENTO E EMPRESA]
    ${phase1 ? JSON.stringify(phase1, null, 2) : "Ainda não preenchido. O usuário deve ir para a aba Fase 1 preencher."}

    [FASE 2 - ENTREVISTAS REALIZADAS]
    ${phase2.length > 0 ? phase2.map(c => `Nome: ${c.name}\nDados: ${JSON.stringify(c.fullPhase2)}`).join('\n---\n') : "Nenhuma entrevista processada ainda."}

    [FASE 3 - SHORTLIST (TABELA COMPARATIVA)]
    ${phase3.length > 0 ? JSON.stringify(phase3, null, 2) : "Shortlist ainda não gerada."}

    [FASE 4 - DECISÃO FINAL]
    ${phase4 ? JSON.stringify(phase4, null, 2) : "Relatório de decisão ainda não gerado."}
  `;

  const systemInstruction = `
    # ROLE
    Você é o Assistente Virtual Inteligente da Evermonte.
    Seu objetivo é ajudar Headhunters e Gestores (RH/Clientes) a navegar pelos dados do processo seletivo atual.

    # CONTEXT
    Você tem acesso total aos dados brutos e processados das 4 fases do recrutamento (Alinhamento, Entrevistas, Shortlist, Decisão).
    Esses dados foram injetados no seu contexto e são atualizados conforme o usuário usa a plataforma.

    # BEHAVIOR
    1. Responda dúvidas específicas sobre candidatos (ex: "Quem tem melhor inglês?").
    2. Faça comparações cruzando dados (ex: "O Candidato X se encaixa na cultura descrita na Fase 1?").
    3. Seja consultivo. Se identificar um risco nos dados, aponte-o.
    4. Seja conciso e direto. Use formatação Markdown (negrito, listas) para facilitar a leitura.
    5. Se o usuário perguntar algo que não está nos dados, diga que não tem essa informação no processo atual.

    # TONE
    Profissional, objetivo e prestativo.
  `;

  // Initialize chat with the context as the first history turn (or system instruction context)
  
  return ai.chats.create({
    model: modelId,
    config: {
      systemInstruction: `${systemInstruction}\n\n${contextData}`,
    },
    history: history
  });
};

export const sendMessageToAssistant = async (
  chat: Chat, 
  message: string
): Promise<string> => {
  try {
    const result = await chat.sendMessage({ message });
    return result.text || "Não consegui processar a resposta.";
  } catch (error) {
    console.error("Chat Error", error);
    return "Desculpe, ocorreu um erro ao consultar a IA. Tente novamente.";
  }
};