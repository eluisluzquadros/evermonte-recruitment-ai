import { GoogleGenAI, Type, Schema } from "@google/genai";
import { Phase1Result, Phase2Result, Phase3Result, Phase4Result } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// --- Phase 1: Alignment ---
export const runPhase1Alignment = async (
  transcript: string,
  companyName: string
): Promise<Phase1Result> => {
  const modelId = "gemini-3-pro-preview";
  
  const systemInstruction = `
    # ROLE
    Você é um Agente Analista de Recrutamento da Evermonte, especialista na Fase 1 - Alinhamento.
    
    # TASK
    Analise a transcrição da reunião de alinhamento e realize 'Deep Research' (usando a tool de busca) sobre a empresa ${companyName}.
    Estruture as informações extraindo necessidades da vaga, cultura, desafios e diferenciais.
    Cruze isso com dados de mercado (faturamento, concorrentes, notícias).

    # OUTPUT
    Retorne estritamente um objeto JSON válido. Não adicione formatação Markdown (code blocks).
    Garanta que os campos de texto (structure, sectorAndCompetitors, jobDetails) sejam strings, não objetos.
  `;

  const prompt = `
    Empresa: ${companyName}
    Transcrição da Reunião:
    ${transcript}

    Gere um JSON com as seguintes chaves:
    - companyName (Nome da empresa - String)
    - structure (Estrutura da empresa, cultura - String formatada)
    - sectorAndCompetitors (Setor, Concorrência e Diferenciais Competitivos - String formatada)
    - jobDetails (Detalhes da Vaga, desafios - String formatada)
    - idealCoreSkills (Array de strings com 3 skills ideais)
  `;

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        tools: [{ googleSearch: {} }],
      },
    });

    let text = response.text || "{}";
    text = text.replace(/```json/g, "").replace(/```/g, "").trim();
    
    let result: Phase1Result;
    try {
        result = JSON.parse(text);
    } catch (e) {
        console.error("JSON Parse Error Phase 1", text);
        const jsonMatch = text.match(/\{[\s\S]*\}/);
        if (jsonMatch) {
             try {
                result = JSON.parse(jsonMatch[0]);
             } catch (e2) {
                throw new Error("Failed to parse AI response.");
             }
        } else {
             throw new Error("Failed to parse AI response.");
        }
    }

    const ensureString = (val: any): string => {
        if (typeof val === 'string') return val;
        if (typeof val === 'number') return String(val);
        if (typeof val === 'object' && val !== null) {
            return Object.entries(val)
                .map(([k, v]) => `${k}: ${typeof v === 'object' ? JSON.stringify(v) : v}`)
                .join('\n');
        }
        return '';
    };

    if (result) {
        result.companyName = ensureString(result.companyName);
        result.structure = ensureString(result.structure);
        result.sectorAndCompetitors = ensureString(result.sectorAndCompetitors);
        result.jobDetails = ensureString(result.jobDetails);
        if (!Array.isArray(result.idealCoreSkills)) {
             result.idealCoreSkills = result.idealCoreSkills ? [ensureString(result.idealCoreSkills)] : [];
        }
    }

    const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks;
    if (chunks && chunks.length > 0) {
        const sources = chunks
            .map(c => c.web?.uri)
            .filter(uri => uri)
            .map(uri => `- ${uri}`)
            .join('\n');
        
        if (sources && result.sectorAndCompetitors) {
            result.sectorAndCompetitors += `\n\nFontes Consultadas:\n${sources}`;
        }
    }

    return result;

  } catch (error) {
    console.error("Phase 1 Error:", error);
    throw error;
  }
};

// --- Phase 2: Interview ---
export const runPhase2Interview = async (
  candidateName: string,
  cvText: string,
  interviewTranscript: string,
  consultantNotes: string
): Promise<Phase2Result> => {
  const modelId = "gemini-3-pro-preview";

  const systemInstruction = `
    # ROLE
    Você é um Agente Avaliador de Talentos da Evermonte, especialista na Fase 2 - Entrevista.
    
    # TASK
    Crie um relatório avaliativo sucinto cruzando: CV, Transcrição da Entrevista e Notas do Consultor.
    Foque em: 3 projetos mais relevantes (Contexto, Desafio, Método, Resultados), Soft Skills e Aderência Cultural.
    Seja executivo, persuasivo e imparcial.
  `;

  const prompt = `
    Candidato: ${candidateName}
    CV (Texto): ${cvText}
    Notas do Consultor: ${consultantNotes}
    Transcrição da Entrevista: ${interviewTranscript}

    Gere um JSON estrito com as chaves solicitadas no padrão Evermonte, incluindo 'currentPosition'.
  `;

  const responseSchema: Schema = {
    type: Type.OBJECT,
    properties: {
      candidateName: { type: Type.STRING },
      currentPosition: { type: Type.STRING },
      interviewerConclusion: { type: Type.STRING },
      experience: { type: Type.STRING },
      mainProjects: { type: Type.STRING },
      motivation: { type: Type.STRING },
      mobility: { type: Type.STRING },
      englishLevel: { type: Type.STRING },
      remuneration: { type: Type.STRING },
      communication: { type: Type.STRING },
      coreSkills: { type: Type.STRING },
      recommendation: { type: Type.STRING },
    },
    required: [
        "candidateName", "currentPosition", "interviewerConclusion", "experience", "mainProjects", 
        "motivation", "mobility", "englishLevel", "remuneration", 
        "communication", "coreSkills", "recommendation"
    ],
  };

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as Phase2Result;
    }
    throw new Error("No response text generated");
  } catch (error) {
    console.error("Phase 2 Error:", error);
    throw error;
  }
};

// --- Phase 3: Shortlist ---
export const runPhase3Shortlist = async (
  candidatesData: { 
    name: string; 
    interviewReport: string; 
    cvText: string;
    fullPhase2?: Phase2Result;
  }[]
): Promise<Phase3Result[]> => {
  const modelId = "gemini-3-pro-preview";

  const systemInstruction = `
    # ROLE
    Você é um Analista de Shortlist da Evermonte.
    
    # TASK
    Analise individualmente cada candidato para compor a tabela de Shortlist.
    NÃO compare candidatos entre si. Avalie cada um estritamente em relação à sua própria trajetória e aderência aos requisitos.
    
    # DATA SOURCES
    Você receberá o 'cvText' (Currículo) e, quando disponível, o objeto 'fullPhase2' (Dados estruturados da Entrevista).
    
    IMPORTANTE:
    - Use SEMPRE os dados de 'fullPhase2' para garantir precisão em: 'currentPosition', 'remuneration', 'motivation' e 'coreSkills'.
    - Use 'fullPhase2.interviewerConclusion' e 'fullPhase2.recommendation' para enriquecer o contexto dos projetos e alinhamento.
  `;

  const prompt = `
    Dados dos Candidatos:
    ${JSON.stringify(candidatesData)}

    Preencha os campos para cada candidato seguindo estas regras de conteúdo:
    1. age: Apenas o número (ex: "34").
    2. location: Cidade / UF.
    3. currentPosition: Use o dado de 'fullPhase2.currentPosition' se disponível, ou extraia do CV.
    4. academicHistory: Lista completa com Entidade, Curso e Data de Conclusão.
    5. professionalExperience: Lista completa com Empresa, Posição, Data Início e Saída.
    6. mainProjects: Descreva detalhadamente os 3 principais projetos (Combine CV + 'fullPhase2.mainProjects' + 'fullPhase2.interviewerConclusion').
    7. coreSkills: Combine skills do CV com 'fullPhase2.coreSkills'.
    8. motivations: Motivos para mudança e interesses (Use 'fullPhase2.motivation' e 'fullPhase2.recommendation' para contexto).
    9. remunerationPackage: Use 'fullPhase2.remuneration' se disponível.
    10. shortlistId: "Candidato 1", "Candidato 2", etc.
  `;

  const responseSchema: Schema = {
    type: Type.ARRAY,
    items: {
        type: Type.OBJECT,
        properties: {
            shortlistId: { type: Type.STRING },
            candidateName: { type: Type.STRING },
            age: { type: Type.STRING },
            currentPosition: { type: Type.STRING },
            location: { type: Type.STRING },
            academicHistory: { type: Type.STRING },
            professionalExperience: { type: Type.STRING },
            mainProjects: { type: Type.STRING },
            remunerationPackage: { type: Type.STRING },
            coreSkills: { type: Type.STRING },
            motivations: { type: Type.STRING }
        },
        required: [
            "shortlistId", "candidateName", "age", "currentPosition", 
            "location", "academicHistory", "professionalExperience", 
            "mainProjects", "remunerationPackage", "coreSkills", "motivations"
        ]
    }
  };

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as Phase3Result[];
    }
    throw new Error("No response text generated");
  } catch (error) {
    console.error("Phase 3 Error:", error);
    throw error;
  }
};

// --- Phase 4: Decision ---
export const runPhase4Decision = async (
  companyData: Phase1Result | null,
  shortlistData: Phase3Result[],
  phase2Data: Phase2Result[],
  candidateDocs: Record<string, { lensMini?: string; competency?: string; leadership?: string; }>
): Promise<Phase4Result> => {
  const modelId = "gemini-3-pro-preview"; 

  const systemInstruction = `
    # ROLE
    Você é a Inteligência Artificial da Evermonte responsável por criar relatórios executivos de apoio à tomada de decisão.
    
    # TASK
    Faça um relatório para preenchimento da posição na empresa ${companyData?.companyName || 'Cliente'}.
    Você DEVE utilizar TODOS os dados fornecidos:
    1. Contexto da Empresa (Fase 1).
    2. Dados da Entrevista e Impressões do Consultor (Fase 2).
    3. Dados Consolidados da Shortlist (Fase 3).
    4. Relatórios Técnicos (Lens Mini, Competência, Liderança).
    
    # GUIDELINES
    1. INTRODUÇÃO: 2 Parágrafos detalhados. Informe que o relatório foi elaborado utilizando *avaliações de entrevistas*, *assessments* e *relatórios técnicos*. Resuma objetivo e retome informações importantes da empresa (Desafios, Cultura).
    
    2. ANÁLISE POR CANDIDATO (Para cada um):
       - SUMÁRIO EXECUTIVO: Apresentação curta em parágrafos descritivos (PROIBIDO formato de lista/tópicos). 
         * Combine a visão pessoal da Fase 2 (Conclusão do entrevistador, Motivação) com os dados técnicos dos relatórios (Personalidade, Liderança).
       - CENÁRIO DE DECISÃO: Foco específico para a posição. Justifique a adequação usando pontos positivos 'POSITIVE' das competências (Relatórios) E das soft skills evidenciadas na entrevista (Fase 2).
       - O PORQUÊ: Argumento de venda do candidato. Foco nos benefícios, adequação e aplicabilidade positiva.
    
    3. RESTRIÇÕES:
       - NÃO apresente notas numéricas isoladas (ex: "Nota 5 em Liderança"), mas interprete o significado.
       - NÃO use listas (bullet points) no sumário executivo.
       - Mantenha tom executivo e persuasivo.
  `;

  const prompt = `
    CONTEXTO DA EMPRESA (FASE 1):
    Nome: ${companyData?.companyName}
    Detalhes da Vaga: ${companyData?.jobDetails}
    Cultura/Estrutura: ${companyData?.structure}

    CANDIDATOS FINALISTAS:
    ${shortlistData.map(c => {
        // Find matching Phase 2 Data
        const p2 = phase2Data.find(p => p.candidateName === c.candidateName);
        
        return `
      ---
      ID: ${c.shortlistId}
      Nome: ${c.candidateName}
      
      [DADOS DA ENTREVISTA - FASE 2]
      Conclusão do Entrevistador: ${p2?.interviewerConclusion || 'N/A'}
      Recomendação: ${p2?.recommendation || 'N/A'}
      Motivação: ${p2?.motivation || 'N/A'}
      Comunicação: ${p2?.communication || 'N/A'}
      
      [DADOS CONSOLIDADOS - FASE 3]
      Projetos: ${c.mainProjects}
      Skills Técnicas: ${c.coreSkills}
      
      [RELATÓRIO 1: LENS MINI (Personalidade/Tipo)]
      ${candidateDocs[c.candidateName]?.lensMini || "Não fornecido."}
      
      [RELATÓRIO 2: COMPETÊNCIA (Skills/Scores)]
      ${candidateDocs[c.candidateName]?.competency || "Não fornecido."}
      
      [RELATÓRIO 3: LIDERANÇA (Gestão/Processos)]
      ${candidateDocs[c.candidateName]?.leadership || "Não fornecido."}
      ---
    `}).join('\n')}

    Gere o JSON exato para preencher a tabela solicitada.
  `;

  const responseSchema: Schema = {
    type: Type.OBJECT,
    properties: {
        introduction: { 
            type: Type.STRING, 
            description: "Texto da coluna INTRODUÇÃO (2 parágrafos detalhados)" 
        },
        candidates: {
            type: Type.ARRAY,
            items: {
                type: Type.OBJECT,
                properties: {
                    shortlistId: { type: Type.STRING },
                    candidateName: { type: Type.STRING },
                    executiveSummary: { type: Type.STRING, description: "SUMÁRIO EXECUTIVO (Parágrafos narrativos, integrando Entrevista + Relatórios)" },
                    decisionScenario: { type: Type.STRING, description: "O CENÁRIO DE DECISÃO" },
                    whyDecision: { type: Type.STRING, description: "O PORQUÊ DO CENÁRIO DE DECISÃO" }
                },
                required: ["shortlistId", "candidateName", "executiveSummary", "decisionScenario", "whyDecision"]
            }
        }
    },
    required: ["introduction", "candidates"]
  };

  try {
    const response = await ai.models.generateContent({
      model: modelId,
      contents: prompt,
      config: {
        systemInstruction: systemInstruction,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
      },
    });

    if (response.text) {
      return JSON.parse(response.text) as Phase4Result;
    }
    throw new Error("No response text generated");
  } catch (error) {
    console.error("Phase 4 Error:", error);
    throw error;
  }
};