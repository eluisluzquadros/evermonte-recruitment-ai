
import React, { useState, useEffect, useRef } from 'react';
import { runPhase4Decision } from '../services/geminiService';
import { Phase3Result, Phase4Result, Phase1Result, Phase2Result } from '../types';
import { Loader2, Upload, FileCheck, AlertCircle, FileText, Brain, Trophy, RefreshCw, FolderInput } from 'lucide-react';
import { parseFile } from '../utils/fileParser';
import { matchFileToCandidate, DocType } from '../utils/fileMatching';

interface Props {
    shortlist: Phase3Result[];
    phase1Data: Phase1Result | null;
    phase2Data: Phase2Result[];
    onDecisionGenerated: (result: Phase4Result) => void;
    savedResult: Phase4Result | null;
}

// Structure to hold the 3 specific documents per candidate
type CandidateDocs = {
    lensMini?: string;
    competency?: string;
    leadership?: string;
};

const Phase4Decision: React.FC<Props> = ({ shortlist, phase1Data, phase2Data, onDecisionGenerated, savedResult }) => {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Phase4Result | null>(savedResult);
  
  // Store uploaded assessment texts per candidate name
  const [candidateDocuments, setCandidateDocuments] = useState<Record<string, CandidateDocs>>({});
  const [processingFiles, setProcessingFiles] = useState<Record<string, boolean>>({});
  
  // Smart Batch Upload State
  const batchInputRef = useRef<HTMLInputElement>(null);
  const [batchProcessing, setBatchProcessing] = useState(false);
  const [matchStats, setMatchStats] = useState<{total: number, matched: number} | null>(null);

  // Sync local state if savedResult changes from outside
  useEffect(() => {
      if (savedResult) {
          setResult(savedResult);
      }
  }, [savedResult]);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, candidateName: string, docType: keyof CandidateDocs) => {
      const file = e.target.files?.[0];
      if (!file) return;

      const processKey = `${candidateName}-${docType}`;
      setProcessingFiles(prev => ({ ...prev, [processKey]: true }));
      
      try {
          const text = await parseFile(file);
          setCandidateDocuments(prev => ({
              ...prev,
              [candidateName]: {
                  ...prev[candidateName],
                  [docType]: text
              }
          }));
      } catch (err) {
          alert(`Erro ao ler arquivo de ${candidateName}`);
      } finally {
          setProcessingFiles(prev => ({ ...prev, [processKey]: false }));
          // Reset input value to allow re-uploading same file if needed
          e.target.value = '';
      }
  };

  const handleBatchUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const files = e.target.files;
      if (!files || files.length === 0) return;

      setBatchProcessing(true);
      let matchedCount = 0;
      const candidateNames = shortlist.map(c => c.candidateName);

      for (let i = 0; i < files.length; i++) {
          const file = files[i];
          
          // 1. Try to match
          const match = matchFileToCandidate(file.name, candidateNames);
          
          if (match) {
              // 2. If matched, parse and assign
              try {
                  const text = await parseFile(file);
                  setCandidateDocuments(prev => ({
                      ...prev,
                      [match.candidateName]: {
                          ...prev[match.candidateName],
                          [match.docType]: text
                      }
                  }));
                  matchedCount++;
              } catch (err) {
                  console.error(`Error reading file ${file.name}`, err);
              }
          } else {
              console.warn(`Could not match file: ${file.name}`);
          }
      }

      setMatchStats({ total: files.length, matched: matchedCount });
      setBatchProcessing(false);
      if (batchInputRef.current) batchInputRef.current.value = '';
      
      // Clear status after 5 seconds
      setTimeout(() => setMatchStats(null), 5000);
  };

  const handleGenerateDecision = async () => {
    if (shortlist.length === 0) return;
    setLoading(true);
    try {
      const data = await runPhase4Decision(phase1Data, shortlist, phase2Data, candidateDocuments);
      setResult(data);
      onDecisionGenerated(data);
    } catch (e) {
      alert("Error generating decision report.");
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const renderUploadButton = (candidateName: string, docType: keyof CandidateDocs, label: string, Icon: React.ElementType) => {
      const isUploaded = !!candidateDocuments[candidateName]?.[docType];
      const isProcessing = processingFiles[`${candidateName}-${docType}`];

      return (
          <label className={`
              flex flex-col items-center justify-center p-3 rounded-lg border border-dashed transition-all cursor-pointer
              ${isUploaded 
                  ? 'bg-green-50 border-green-300 text-green-700 shadow-sm' 
                  : 'bg-white border-gray-300 hover:bg-gray-50 text-gray-600 hover:border-blue-400'}
          `}>
              <input 
                  type="file" 
                  className="hidden" 
                  accept=".pdf,.docx,.txt"
                  disabled={isProcessing}
                  onChange={(e) => handleFileUpload(e, candidateName, docType)}
              />
              
              {isProcessing ? (
                  <Loader2 className="w-5 h-5 animate-spin mb-1 text-blue-500" />
              ) : isUploaded ? (
                  <FileCheck className="w-5 h-5 mb-1" />
              ) : (
                  <Icon className="w-5 h-5 mb-1 text-gray-400" />
              )}
              
              <span className="text-[10px] font-medium text-center leading-tight">
                  {isUploaded ? "Anexado" : label}
              </span>
          </label>
      );
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden flex flex-col h-full">
      <div className="p-6 border-b border-gray-100 shrink-0 flex flex-col md:flex-row justify-between md:items-center gap-4">
        <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-1">Fase 4: Tomada de Decisão</h2>
            <p className="text-gray-500">Relatório executivo combinando Fases 1, 2, 3 e Relatórios Cognisess.</p>
        </div>
        {result && (
            <button 
                onClick={handleGenerateDecision} 
                disabled={loading}
                className="text-sm flex items-center text-blue-600 hover:bg-blue-50 px-3 py-2 rounded-lg transition-colors"
            >
                {loading ? <Loader2 className="animate-spin w-4 h-4 mr-2"/> : <RefreshCw className="w-4 h-4 mr-2" />}
                Regerar Relatório
            </button>
        )}
      </div>

      <div className="p-6 overflow-y-auto">
          {shortlist.length === 0 ? (
               <div className="bg-yellow-50 p-6 rounded-lg text-yellow-800 text-center border border-yellow-200">
                   <AlertCircle className="w-8 h-8 mx-auto mb-2 text-yellow-600"/>
                   <h3 className="font-bold mb-1">Aguardando Shortlist</h3>
                   <p className="text-sm">Finalize a Fase 3 antes de prosseguir para a decisão.</p>
               </div>
          ) : (
            <div className="space-y-6">
                <div className={`bg-slate-50 border border-slate-200 rounded-lg p-5 transition-all ${result ? 'opacity-75 hover:opacity-100' : ''}`}>
                    <div className="flex flex-col md:flex-row justify-between md:items-center mb-4 gap-4">
                        <div>
                            <h3 className="font-bold text-slate-800 flex items-center">
                                <Upload className="w-4 h-4 mr-2"/> 
                                Relatórios de Input (Obrigatórios)
                            </h3>
                            <p className="text-xs text-slate-600 mt-1">
                                Para cada finalista, anexe os 3 relatórios (Lens Mini, Competência, Liderança).
                            </p>
                        </div>
                        
                        {/* Smart Batch Upload Button */}
                        <div className="flex flex-col items-end">
                            <button 
                                onClick={() => batchInputRef.current?.click()}
                                disabled={batchProcessing}
                                className="flex items-center px-4 py-2 bg-indigo-100 text-indigo-700 border border-indigo-200 rounded-lg hover:bg-indigo-200 transition-colors text-xs font-bold shadow-sm"
                            >
                                {batchProcessing ? <Loader2 className="w-3 h-3 mr-2 animate-spin"/> : <FolderInput className="w-3 h-3 mr-2"/>}
                                {batchProcessing ? "Processando..." : "Upload Inteligente em Lote"}
                            </button>
                            <input 
                                type="file" 
                                multiple 
                                ref={batchInputRef} 
                                className="hidden" 
                                accept=".pdf,.docx,.txt"
                                onChange={handleBatchUpload} 
                            />
                            {matchStats && (
                                <span className="text-[10px] text-green-600 font-medium mt-1">
                                    {matchStats.matched} de {matchStats.total} arquivos associados.
                                </span>
                            )}
                        </div>
                    </div>
                    
                    <div className="grid gap-4">
                        {shortlist.map((candidate, idx) => (
                            <div key={idx} className="bg-white p-4 rounded border border-slate-200 shadow-sm hover:shadow-md transition-shadow">
                                <div className="flex items-center mb-3 border-b border-gray-100 pb-2">
                                    <div className="w-6 h-6 rounded-full bg-indigo-100 text-indigo-600 flex items-center justify-center text-xs font-bold mr-3">
                                        {idx + 1}
                                    </div>
                                    <span className="font-semibold text-gray-800">{candidate.candidateName}</span>
                                </div>
                                
                                <div className="grid grid-cols-3 gap-3">
                                    {renderUploadButton(candidate.candidateName, 'lensMini', 'Lens Mini', Brain)}
                                    {renderUploadButton(candidate.candidateName, 'competency', 'Competência', FileText)}
                                    {renderUploadButton(candidate.candidateName, 'leadership', 'Liderança', Trophy)}
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                {!result && (
                    <button
                        onClick={handleGenerateDecision}
                        disabled={loading}
                        className="w-full flex items-center justify-center bg-emerald-600 hover:bg-emerald-700 text-white font-semibold py-3 px-6 rounded-lg transition-colors shadow-sm disabled:opacity-50 transform hover:-translate-y-0.5"
                    >
                        {loading ? <Loader2 className="animate-spin mr-2" /> : "Gerar Relatório de Decisão"}
                    </button>
                )}
            </div>
          )}

          {result && (
              <div className="mt-8 animate-fade-in">
                  <h3 className="text-lg font-bold text-gray-800 mb-4">Relatório de Apoio à Tomada de Decisão</h3>
                  <div className="overflow-x-auto border border-gray-300 rounded-lg shadow-sm">
                      <table className="min-w-full text-sm border-collapse">
                          <thead className="bg-gray-100 text-gray-700 font-bold uppercase text-xs">
                              <tr>
                                  <th className="border border-gray-300 px-4 py-3 text-left w-64">Introdução</th>
                                  <th className="border border-gray-300 px-4 py-3 text-left w-32">Shortlist</th>
                                  <th className="border border-gray-300 px-4 py-3 text-left w-48">Candidato</th>
                                  <th className="border border-gray-300 px-4 py-3 text-left w-96">Sumário Executivo</th>
                                  <th className="border border-gray-300 px-4 py-3 text-left w-80">O Cenário de Decisão</th>
                                  <th className="border border-gray-300 px-4 py-3 text-left w-80">O Porquê do Cenário</th>
                              </tr>
                          </thead>
                          <tbody className="bg-white text-gray-800">
                              {result.candidates.map((candidate, index) => (
                                  <tr key={index}>
                                      {/* Introduction cell spans all rows, rendered only on the first row */}
                                      {index === 0 && (
                                          <td 
                                            rowSpan={result.candidates.length} 
                                            className="border border-gray-300 px-4 py-4 align-top text-gray-600 leading-relaxed bg-gray-50 text-xs"
                                          >
                                              {result.introduction}
                                          </td>
                                      )}
                                      <td className="border border-gray-300 px-4 py-4 align-top font-bold text-indigo-900 bg-indigo-50/20">
                                          {candidate.shortlistId}
                                      </td>
                                      <td className="border border-gray-300 px-4 py-4 align-top font-semibold">
                                          {candidate.candidateName}
                                      </td>
                                      <td className="border border-gray-300 px-4 py-4 align-top leading-relaxed whitespace-pre-wrap text-justify">
                                          {candidate.executiveSummary}
                                      </td>
                                      <td className="border border-gray-300 px-4 py-4 align-top leading-relaxed whitespace-pre-wrap bg-emerald-50/30 text-justify">
                                          {candidate.decisionScenario}
                                      </td>
                                      <td className="border border-gray-300 px-4 py-4 align-top leading-relaxed whitespace-pre-wrap text-justify">
                                          {candidate.whyDecision}
                                      </td>
                                  </tr>
                              ))}
                          </tbody>
                      </table>
                  </div>
              </div>
          )}
      </div>
    </div>
  );
};

export default Phase4Decision;
