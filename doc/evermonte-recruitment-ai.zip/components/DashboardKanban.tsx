import React, { useState } from 'react';
import { Phase1Result, Phase2Result, Phase3Result, Phase4Result } from '../types';
import { User, FileText, CheckCircle, Briefcase, ArrowRight, LayoutDashboard, Search, AlertCircle, Sparkles, AlertTriangle, TrendingUp, Lightbulb, Loader2, Presentation } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createChatSession, sendMessageToAssistant } from '../services/chatService';

interface Props {
  candidates: { name: string; fullPhase2: Phase2Result }[];
  shortlist: Phase3Result[];
  phase4Result: Phase4Result | null;
  phase1Data?: Phase1Result | null; // Make optional to support legacy calls, but we will pass it from App
}

interface Insight {
    category: string;
    text: string;
    type: 'warning' | 'info' | 'success';
    icon: React.ElementType;
}

// Extend Props in App.tsx usage
const DashboardKanban: React.FC<Props> = ({ candidates, shortlist, phase4Result, phase1Data }) => {
  // Helper to check status
  const isShortlisted = (name: string) => shortlist.some(s => s.candidateName === name);
  const isDecided = (name: string) => phase4Result?.candidates.some(c => c.candidateName === name);

  // Column 3: Decided
  const decidedCandidates = phase4Result?.candidates || [];
  
  // Column 2: Shortlisted BUT NOT Decided
  const shortlistedCandidates = shortlist.filter(s => !isDecided(s.candidateName));

  // Column 1: Interviewed BUT NOT Shortlisted
  const interviewCandidates = candidates.filter(c => !isShortlisted(c.name));

  const totalCandidates = candidates.length;
  const conversionRate = totalCandidates > 0 ? Math.round((shortlist.length / totalCandidates) * 100) : 0;

  // Insights State
  const [insights, setInsights] = useState<Insight[]>([]);
  const [loadingInsights, setLoadingInsights] = useState(false);
  const [insightsGenerated, setInsightsGenerated] = useState(false);

  const generateProactiveInsights = async () => {
      if (!phase1Data && candidates.length === 0) return;
      setLoadingInsights(true);

      try {
          // Create a temporary chat session with full context
          const chat = createChatSession(phase1Data || null, candidates, shortlist, phase4Result);

          // Define strategic prompts
          const promptCultural = "Com base estritamente na cultura e desafios definidos na Fase 1, identifique se algum candidato avaliado na Fase 2 apresenta risco de desalinhamento cultural (Red Flag). Se não houver, diga 'Sem riscos evidentes'. Seja direto, máx 1 frase.";
          const promptSalary = "Analise as pretensões salariais dos candidatos. Há alguém muito fora do provável budget ou senioridade da vaga? Responda em 1 frase.";
          const promptHighlight = "Qual é o maior diferencial competitivo (ponto forte) que se destaca entre os candidatos da Shortlist (ou entrevistados)? Responda em 1 frase.";

          // Run in parallel for speed
          const [resCultural, resSalary, resHighlight] = await Promise.all([
              sendMessageToAssistant(chat, promptCultural),
              sendMessageToAssistant(chat, promptSalary),
              sendMessageToAssistant(chat, promptHighlight)
          ]);

          setInsights([
              { 
                  category: 'Análise de Risco Cultural', 
                  text: resCultural, 
                  type: resCultural.toLowerCase().includes('sem riscos') ? 'success' : 'warning',
                  icon: resCultural.toLowerCase().includes('sem riscos') ? CheckCircle : AlertTriangle
              },
              { 
                  category: 'Budget & Remuneração', 
                  text: resSalary, 
                  type: 'info',
                  icon: TrendingUp
              },
              { 
                  category: 'Destaque do Pipeline', 
                  text: resHighlight, 
                  type: 'success',
                  icon: Lightbulb
              }
          ]);
          setInsightsGenerated(true);

      } catch (error) {
          console.error("Error generating insights", error);
      } finally {
          setLoadingInsights(false);
      }
  };

  return (
    <div className="h-full flex flex-col bg-gray-50 p-4 md:p-8">
      {/* Header Stats */}
      <div className="bg-white rounded-2xl border border-gray-200 p-6 shrink-0 space-y-6 shadow-sm">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div>
                <h2 className="text-2xl font-bold text-gray-800">Dashboard de Recrutamento</h2>
                <p className="text-gray-500 text-sm mt-1">Visão geral do funil e status dos candidatos.</p>
            </div>
            <div className="flex gap-4">
                <Link to="/report" className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-medium shadow-sm flex items-center transition-colors">
                    <Presentation className="w-4 h-4 mr-2" />
                    Ver Relatório Cliente
                </Link>
                <div className="px-4 py-2 bg-blue-50 rounded-lg border border-blue-100 min-w-[120px]">
                    <span className="block text-xs text-blue-600 font-bold uppercase tracking-wider">Total</span>
                    <span className="text-xl font-bold text-blue-900">{totalCandidates} Candidatos</span>
                </div>
                <div className="px-4 py-2 bg-indigo-50 rounded-lg border border-indigo-100 min-w-[120px]">
                    <span className="block text-xs text-indigo-600 font-bold uppercase tracking-wider">Conversão</span>
                    <span className="text-xl font-bold text-indigo-900">{conversionRate}% Shortlist</span>
                </div>
            </div>
        </div>

        {/* Phase 1 Status Card */}
        <div className="bg-slate-50 border border-slate-200 rounded-xl p-4 flex items-center justify-between shadow-sm">
            <div className="flex items-center gap-4">
                <div className={`p-3 rounded-full ${phase1Data ? 'bg-green-100 text-green-600' : 'bg-gray-200 text-gray-500'}`}>
                    <LayoutDashboard className="w-5 h-5" />
                </div>
                <div>
                    <h3 className="text-sm font-bold text-gray-700 uppercase tracking-wide">Fase 1: Alinhamento & Cultura</h3>
                    {phase1Data ? (
                        <div className="flex items-center mt-1">
                            <span className="font-semibold text-gray-900 mr-2">{phase1Data.companyName}</span>
                            <span className="text-xs bg-green-100 text-green-700 px-2 py-0.5 rounded-full font-medium flex items-center">
                                <CheckCircle className="w-3 h-3 mr-1"/> Concluído
                            </span>
                        </div>
                    ) : (
                        <div className="flex items-center mt-1 text-sm text-gray-500">
                             <span className="mr-2">Aguardando dados da reunião...</span>
                             <Link to="/phase1" className="text-blue-600 hover:underline text-xs flex items-center">
                                Iniciar Fase 1 <ArrowRight className="w-3 h-3 ml-1"/>
                             </Link>
                        </div>
                    )}
                </div>
            </div>
            {phase1Data && (
                <div className="hidden md:block text-right">
                    <div className="text-xs text-gray-400 uppercase">Core Skills Mapeadas</div>
                    <div className="text-sm font-medium text-gray-600 max-w-[200px] truncate">
                        {phase1Data.idealCoreSkills.join(', ')}
                    </div>
                </div>
            )}
        </div>

        {/* AI Insights Section */}
        {phase1Data && candidates.length > 0 && (
            <div className="space-y-3">
                <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-gray-700 flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-purple-600" />
                        Insights Proativos da IA
                    </h3>
                    {!insightsGenerated && !loadingInsights && (
                        <button 
                            onClick={generateProactiveInsights}
                            className="text-xs bg-purple-600 text-white px-3 py-1.5 rounded-md font-medium hover:bg-purple-700 transition-colors shadow-sm flex items-center"
                        >
                            <Sparkles className="w-3 h-3 mr-1.5" />
                            Analisar Riscos & Oportunidades
                        </button>
                    )}
                </div>

                {loadingInsights ? (
                    <div className="p-8 border border-dashed border-gray-200 rounded-xl bg-gray-50 flex flex-col items-center justify-center text-gray-400">
                        <Loader2 className="w-6 h-6 animate-spin mb-2 text-purple-500" />
                        <span className="text-xs font-medium">O Agente está analisando os dados dos candidatos...</span>
                    </div>
                ) : insights.length > 0 ? (
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        {insights.map((insight, idx) => (
                            <div 
                                key={idx} 
                                className={`p-4 rounded-lg border shadow-sm flex items-start gap-3
                                    ${insight.type === 'warning' ? 'bg-amber-50 border-amber-200' : 
                                      insight.type === 'success' ? 'bg-emerald-50 border-emerald-200' : 
                                      'bg-blue-50 border-blue-200'}
                                `}
                            >
                                <div className={`p-2 rounded-full shrink-0 
                                    ${insight.type === 'warning' ? 'bg-amber-100 text-amber-600' : 
                                      insight.type === 'success' ? 'bg-emerald-100 text-emerald-600' : 
                                      'bg-blue-100 text-blue-600'}
                                `}>
                                    <insight.icon className="w-4 h-4" />
                                </div>
                                <div>
                                    <h4 className={`text-xs font-bold uppercase tracking-wider mb-1
                                        ${insight.type === 'warning' ? 'text-amber-700' : 
                                          insight.type === 'success' ? 'text-emerald-700' : 
                                          'text-blue-700'}
                                    `}>
                                        {insight.category}
                                    </h4>
                                    <p className="text-sm text-gray-800 leading-snug">
                                        {insight.text}
                                    </p>
                                </div>
                            </div>
                        ))}
                    </div>
                ) : null}
            </div>
        )}
      </div>

      {/* Kanban Board */}
      <div className="flex-1 overflow-x-auto overflow-y-hidden pt-6">
        <div className="flex h-full gap-6 min-w-[1000px]">
            
            {/* Column 1: Entrevistas */}
            <div className="flex-1 flex flex-col bg-gray-100 rounded-xl border border-gray-200 max-w-md">
                <div className="p-4 border-b border-gray-200 flex justify-between items-center bg-white rounded-t-xl">
                    <h3 className="font-bold text-gray-700 flex items-center">
                        <User className="w-4 h-4 mr-2 text-gray-500" />
                        Entrevistados (Fase 2)
                    </h3>
                    <span className="bg-gray-100 text-gray-600 text-xs px-2 py-1 rounded-full font-bold">{interviewCandidates.length}</span>
                </div>
                <div className="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                    {interviewCandidates.length === 0 && candidates.length === 0 && (
                        <div className="text-center p-6 text-gray-400 border-2 border-dashed border-gray-200 rounded-lg">
                            <p className="text-sm">Nenhum candidato processado.</p>
                            <Link to="/phase2" className="text-blue-600 hover:underline text-xs mt-2 block">Ir para Entrevistas</Link>
                        </div>
                    )}
                    {interviewCandidates.map((c, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 hover:shadow-md transition-shadow border-l-4 border-l-gray-300">
                            <div className="font-semibold text-gray-800">{c.name}</div>
                            <div className="text-xs text-gray-500 mt-1 line-clamp-2">{c.fullPhase2.interviewerConclusion}</div>
                            <div className="mt-3 flex justify-between items-center">
                                <span className="text-[10px] px-2 py-1 bg-gray-100 rounded text-gray-600">Recomendação: {c.fullPhase2.recommendation}</span>
                                <Link to="/phase3" className="text-gray-400 hover:text-blue-600">
                                    <ArrowRight className="w-4 h-4" />
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Column 2: Shortlist */}
            <div className="flex-1 flex flex-col bg-indigo-50/50 rounded-xl border border-indigo-100 max-w-md">
                <div className="p-4 border-b border-indigo-100 flex justify-between items-center bg-white rounded-t-xl">
                    <h3 className="font-bold text-indigo-800 flex items-center">
                        <FileText className="w-4 h-4 mr-2 text-indigo-500" />
                        Shortlist (Fase 3)
                    </h3>
                    <span className="bg-indigo-100 text-indigo-700 text-xs px-2 py-1 rounded-full font-bold">{shortlistedCandidates.length}</span>
                </div>
                <div className="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                    {shortlistedCandidates.length === 0 && shortlist.length === 0 && (
                        <div className="text-center p-6 text-indigo-300 border-2 border-dashed border-indigo-200 rounded-lg">
                            <p className="text-sm">Aguardando seleção.</p>
                        </div>
                    )}
                    {shortlistedCandidates.map((s, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border border-indigo-100 hover:shadow-md transition-shadow border-l-4 border-l-indigo-400 group">
                            <div className="flex justify-between items-start">
                                <div className="font-semibold text-gray-800">{s.candidateName}</div>
                                <span className="text-[10px] font-bold bg-indigo-50 text-indigo-700 px-1.5 py-0.5 rounded">{s.shortlistId}</span>
                            </div>
                            <div className="flex items-center text-xs text-gray-500 mt-1">
                                <Briefcase className="w-3 h-3 mr-1" />
                                {s.currentPosition || 'N/A'}
                            </div>
                            <div className="mt-3 pt-2 border-t border-gray-50 flex justify-between items-center">
                                <div className="text-[10px] text-gray-400">Dados Consolidados</div>
                                <Link to="/phase4" className="text-indigo-400 hover:text-indigo-600 opacity-0 group-hover:opacity-100 transition-opacity">
                                    <ArrowRight className="w-4 h-4" />
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

            {/* Column 3: Decisão */}
            <div className="flex-1 flex flex-col bg-emerald-50/50 rounded-xl border border-emerald-100 max-w-md">
                <div className="p-4 border-b border-emerald-100 flex justify-between items-center bg-white rounded-t-xl">
                    <h3 className="font-bold text-emerald-800 flex items-center">
                        <CheckCircle className="w-4 h-4 mr-2 text-emerald-500" />
                        Decisão Final (Fase 4)
                    </h3>
                    <span className="bg-emerald-100 text-emerald-700 text-xs px-2 py-1 rounded-full font-bold">{decidedCandidates.length}</span>
                </div>
                <div className="p-3 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                    {decidedCandidates.length === 0 && (
                        <div className="text-center p-6 text-emerald-300 border-2 border-dashed border-emerald-200 rounded-lg">
                            <p className="text-sm">Nenhum relatório final gerado.</p>
                        </div>
                    )}
                    {decidedCandidates.map((d, idx) => (
                        <div key={idx} className="bg-white p-4 rounded-lg shadow-sm border border-emerald-100 hover:shadow-md transition-shadow border-l-4 border-l-emerald-500">
                            <div className="font-semibold text-gray-800">{d.candidateName}</div>
                            <div className="text-xs text-emerald-700 mt-1 font-medium">Relatório Executivo Pronto</div>
                            <p className="text-[10px] text-gray-500 mt-2 line-clamp-3 italic">
                                "{d.whyDecision}"
                            </p>
                            <div className="mt-3 flex justify-end">
                                <Link to="/phase4" className="text-xs font-medium text-emerald-600 hover:underline flex items-center">
                                    Ver Relatório
                                </Link>
                            </div>
                        </div>
                    ))}
                </div>
            </div>

        </div>
      </div>
    </div>
  );
};

export default DashboardKanban;