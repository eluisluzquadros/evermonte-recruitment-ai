
import React, { useState, useRef, useEffect } from 'react';
import { runPhase1Alignment } from '../services/geminiService';
import { Phase1Result } from '../types';
import { Loader2, Copy, CheckCircle, Upload, Mail, HardDrive, FilePlus } from 'lucide-react';
import GmailPicker from './GmailPicker';
import DrivePicker from './DrivePicker';
import { parseFile } from '../utils/fileParser';

interface Props {
    onComplete?: (result: Phase1Result) => void;
    savedData?: Phase1Result | null;
}

const Phase1Alignment: React.FC<Props> = ({ onComplete, savedData }) => {
  const [companyName, setCompanyName] = useState(savedData?.companyName || '');
  const [transcript, setTranscript] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Phase1Result | null>(savedData || null);
  const [copied, setCopied] = useState(false);
  const [showGmailPicker, setShowGmailPicker] = useState(false);
  const [showDrivePicker, setShowDrivePicker] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [parsingFile, setParsingFile] = useState(false);

  useEffect(() => {
      if (savedData) {
          setResult(savedData);
          setCompanyName(savedData.companyName);
      }
  }, [savedData]);

  const handleProcess = async () => {
    if (!companyName || !transcript) return;
    setLoading(true);
    try {
      const data = await runPhase1Alignment(transcript, companyName);
      setResult(data);
      if (onComplete) onComplete(data);
    } catch (e) {
      console.error(e);
      alert("Failed to process alignment phase. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = () => {
    if (!result) return;
    const text = `
Empresa: ${result.companyName}
Estrutura: ${result.structure}
Setor/Concorrência: ${result.sectorAndCompetitors}
Detalhes da Vaga: ${result.jobDetails}
Core Skills: ${result.idealCoreSkills.join(', ')}
    `;
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setParsingFile(true);
    let combinedText = transcript ? transcript + "\n\n" : "";
    let processedCount = 0;

    try {
        for (let i = 0; i < files.length; i++) {
            const file = files[i];
            const text = await parseFile(file);
            combinedText += `--- INÍCIO DO ARQUIVO: ${file.name} ---\n${text}\n--- FIM DO ARQUIVO ---\n\n`;
            processedCount++;
        }
        setTranscript(combinedText);
    } catch (error: any) {
        alert(error.message || "Failed to parse file");
    } finally {
        setParsingFile(false);
        // Clear input so same file can be selected again if needed
        if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
      {showGmailPicker && (
          <GmailPicker 
            onSelect={(text) => setTranscript(prev => prev + "\n\n--- Importado do Gmail ---\n" + text)} 
            onClose={() => setShowGmailPicker(false)} 
          />
      )}
      {showDrivePicker && (
          <DrivePicker
            onSelect={(text) => setTranscript(prev => prev + "\n\n--- Importado do Google Drive ---\n" + text)}
            onClose={() => setShowDrivePicker(false)}
          />
      )}

      <div className="p-6 border-b border-gray-100">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Fase 1: Alinhamento</h2>
        <p className="text-gray-500">Análise da transcrição da reunião e pesquisa de mercado (Deep Research).</p>
      </div>

      <div className="p-6 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nome da Empresa</label>
            <input
                type="text"
                value={companyName}
                onChange={(e) => setCompanyName(e.target.value)}
                className="w-full p-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none"
                placeholder="Ex: Saipos"
            />
            </div>
            <div className="hidden md:block"></div>
        </div>

        <div>
          <div className="flex flex-wrap justify-between items-center mb-2 gap-2">
            <label className="block text-sm font-medium text-gray-700">Contexto (Transcrição / Notas / Documentos)</label>
            <div className="flex gap-2 flex-wrap">
                <button 
                    onClick={() => setShowDrivePicker(true)}
                    className="text-xs flex items-center px-2 py-1 bg-green-50 text-green-700 hover:bg-green-100 rounded-md font-medium transition-colors border border-green-200"
                >
                    <HardDrive className="w-3 h-3 mr-1" /> Drive
                </button>
                <button 
                    onClick={() => setShowGmailPicker(true)}
                    className="text-xs flex items-center px-2 py-1 bg-red-50 text-red-700 hover:bg-red-100 rounded-md font-medium transition-colors border border-red-200"
                >
                    <Mail className="w-3 h-3 mr-1" /> Gmail
                </button>
                <button 
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs flex items-center px-2 py-1 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-md font-medium transition-colors border border-blue-200"
                    disabled={parsingFile}
                >
                    {parsingFile ? <Loader2 className="animate-spin w-3 h-3 mr-1"/> : <FilePlus className="w-3 h-3 mr-1" />}
                    {parsingFile ? "Processando..." : "Adicionar Arquivos"}
                </button>
            </div>
            <input 
                type="file" 
                multiple
                ref={fileInputRef} 
                className="hidden" 
                accept=".txt,.md,.csv,.json,.pdf,.docx"
                onChange={handleFileUpload}
            />
          </div>
          <textarea
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
            className="w-full p-3 border border-gray-300 rounded-lg h-40 focus:ring-2 focus:ring-blue-500 focus:outline-none text-sm font-mono leading-relaxed"
            placeholder="Cole o texto da reunião ou faça upload de múltiplos arquivos (PDF, DOCX, TXT) para compor o contexto..."
          />
          <p className="text-xs text-gray-400 mt-1 text-right">
              Você pode adicionar múltiplos arquivos para enriquecer o contexto.
          </p>
        </div>

        <button
          onClick={handleProcess}
          disabled={loading || !companyName || !transcript}
          className="flex items-center justify-center w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed shadow-md hover:shadow-lg"
        >
          {loading ? (
            <>
              <Loader2 className="animate-spin mr-2 h-5 w-5" />
              Processando com IA...
            </>
          ) : (
            "Gerar Relatório de Alinhamento"
          )}
        </button>
      </div>

      {result && (
        <div className="bg-gray-50 p-6 border-t border-gray-200 animate-fade-in">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-lg font-bold text-gray-800">Resultado da Análise</h3>
            <button
              onClick={handleCopy}
              className="flex items-center text-sm font-medium text-blue-600 hover:text-blue-800 bg-white px-3 py-1.5 rounded-md border border-gray-200 shadow-sm"
            >
              {copied ? <CheckCircle className="h-4 w-4 mr-1 text-green-500" /> : <Copy className="h-4 w-4 mr-1" />}
              {copied ? "Copiado!" : "Copiar Texto"}
            </button>
          </div>
          
          <div className="space-y-6 text-sm text-gray-700">
            <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-1">Empresa</div>
                <div className="text-lg font-semibold text-gray-900">{result.companyName}</div>
            </div>

            <div className="grid grid-cols-1 gap-6">
                <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Estrutura & Cultura</div>
                    <div className="whitespace-pre-wrap leading-relaxed text-gray-800 break-words">{result.structure}</div>
                </div>

                <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Setor & Concorrência</div>
                    <div className="whitespace-pre-wrap leading-relaxed text-gray-800 break-words">{result.sectorAndCompetitors}</div>
                </div>

                <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-sm">
                    <div className="text-xs font-bold text-gray-400 uppercase tracking-wider mb-2">Detalhes da Vaga</div>
                    <div className="whitespace-pre-wrap leading-relaxed text-gray-800 break-words">{result.jobDetails}</div>
                </div>
            </div>

             <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                <div className="text-xs font-bold text-blue-600 uppercase tracking-wider mb-2">Core Skills Ideais</div>
                <ul className="list-disc list-inside space-y-1">
                    {result.idealCoreSkills.map((skill, i) => (
                        <li key={i} className="text-blue-900 font-medium">{skill}</li>
                    ))}
                </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Phase1Alignment;
