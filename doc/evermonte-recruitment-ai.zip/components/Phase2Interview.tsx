import React, { useState, useRef, useEffect } from 'react';
import { runPhase2Interview } from '../services/geminiService';
import { Phase2Result } from '../types';
import { Loader2, Plus, Upload, Mail, HardDrive, Check, Save, Edit2, X, FileText, Play, AlertCircle, Trash2, FileStack } from 'lucide-react';
import GmailPicker from './GmailPicker';
import DrivePicker from './DrivePicker';
import { parseFile } from '../utils/fileParser';

interface Props {
    onCandidateEvaluated: (candidate: Phase2Result, cvText: string, reportText: string) => void;
    pendingFiles?: any[]; // Keeping prop for future Universal Upload integration
}

// Queue item structure now supports multiple files per candidate
interface QueueItem {
    id: string;
    candidateName: string;
    files: File[];
    status: 'pending' | 'processing' | 'success' | 'error';
    result?: Phase2Result;
    errorMsg?: string;
}

const Phase2Interview: React.FC<Props> = ({ onCandidateEvaluated }) => {
  // --- Single Mode States ---
  const [candidateName, setCandidateName] = useState('');
  const [cvText, setCvText] = useState('');
  const [interviewTranscript, setInterviewTranscript] = useState('');
  const [consultantNotes, setConsultantNotes] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<Phase2Result | null>(null);
  const [showGmailPicker, setShowGmailPicker] = useState(false);
  const [showDrivePicker, setShowDrivePicker] = useState<'cv' | 'transcript' | null>(null);
  
  const [parsingCv, setParsingCv] = useState(false);
  const [parsingTranscript, setParsingTranscript] = useState(false);
  const [isEditing, setIsEditing] = useState(false);

  const cvInputRef = useRef<HTMLInputElement>(null);
  const transcriptInputRef = useRef<HTMLInputElement>(null);

  // --- Batch Mode States ---
  const [batchQueue, setBatchQueue] = useState<QueueItem[]>([]);
  const [isProcessingBatch, setIsProcessingBatch] = useState(false);
  const batchInputRef = useRef<HTMLInputElement>(null);

  // Form state for editing
  const [editedResult, setEditedResult] = useState<Phase2Result | null>(null);

  useEffect(() => {
    if (result) {
        setEditedResult(result);
        setIsEditing(true);
    }
  }, [result]);

  // --- Single Mode Logic ---
  const handleProcess = async () => {
    if (!candidateName || !cvText) return;
    setLoading(true);
    try {
      // If no transcript is provided in single mode, we warn or pass a placeholder
      const transcriptToUse = interviewTranscript || "Nenhuma transcrição fornecida. Basear análise apenas no CV e Notas.";
      
      const data = await runPhase2Interview(candidateName, cvText, transcriptToUse, consultantNotes);
      setResult(data);
    } catch (e) {
      alert("Error processing interview data.");
    } finally {
      setLoading(false);
    }
  };

  const handleSaveToPipeline = () => {
      if (!editedResult) return;
      
      onCandidateEvaluated(
          editedResult, 
          cvText, 
          `Conclusão: ${editedResult.interviewerConclusion}.`
      );
      
      handleReset();
      alert("Candidato validado e adicionado à Pipeline com sucesso!");
  };

  const handleReset = () => {
      setCandidateName('');
      setCvText('');
      setInterviewTranscript('');
      setConsultantNotes('');
      setResult(null);
      setEditedResult(null);
      setIsEditing(false);
  }

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>, target: 'cv' | 'transcript') => {
      const file = e.target.files?.[0];
      if (!file) return;

      const setter = target === 'cv' ? setCvText : setInterviewTranscript;
      const loadingSetter = target === 'cv' ? setParsingCv : setParsingTranscript;
      const inputRef = target === 'cv' ? cvInputRef : transcriptInputRef;

      loadingSetter(true);
      try {
          const text = await parseFile(file);
          setter(text);
      } catch (error: any) {
          alert(error.message || "Failed to parse file");
      } finally {
          loadingSetter(false);
          if (inputRef.current) inputRef.current.value = '';
      }
  }

  const updateField = (field: keyof Phase2Result, value: string) => {
      if (editedResult) {
          setEditedResult({ ...editedResult, [field]: value });
      }
  };

  // --- Batch Mode Logic ---

  // Helper to normalize filename and extract candidate name
  // "Paulo - CV.pdf" -> "Paulo"
  // "Saul_Souza_Transcript.pdf" -> "Saul Souza"
  const extractNameFromFilename = (filename: string): string => {
      let name = filename.substring(0, filename.lastIndexOf('.')); // Remove extension
      name = name.toLowerCase();
      
      // Replace common separators with spaces
      name = name.replace(/[-_]/g, ' ');
      
      // Remove common keywords (keywords are case insensitive in regex)
      const keywords = ['cv', 'curriculo', 'currículo', 'resume', 'transcricao', 'transcrição', 'entrevista', 'interview', 'meeting', 'reuniao', 'anotacoes', 'notas', 'alinhamento'];
      
      keywords.forEach(k => {
          // Remove word if it stands alone or is at start/end
          const regex = new RegExp(`\\b${k}\\b`, 'gi');
          name = name.replace(regex, '');
      });

      // Clean up extra spaces
      return name.replace(/\s+/g, ' ').trim();
  };

  const handleBatchSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files && e.target.files.length > 0) {
          const files: File[] = Array.from(e.target.files);
          const newItemsMap = new Map<string, File[]>();

          // Group files by extracted candidate name
          files.forEach(file => {
              const extractedName = extractNameFromFilename(file.name);
              // If extraction results in empty string (e.g. file was just "CV.pdf"), use filename
              const key = extractedName.length > 2 ? extractedName : file.name;
              
              if (!newItemsMap.has(key)) {
                  newItemsMap.set(key, []);
              }
              newItemsMap.get(key)?.push(file);
          });

          const newQueueItems: QueueItem[] = Array.from(newItemsMap.entries()).map(([name, candidateFiles]) => ({
              id: Math.random().toString(36).substring(7),
              candidateName: name.split(' ').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' '), // Capitalize
              files: candidateFiles,
              status: 'pending'
          }));

          setBatchQueue(prev => [...prev, ...newQueueItems]);
      }
      
      if (batchInputRef.current) batchInputRef.current.value = '';
  };

  const processBatchQueue = async () => {
      if (isProcessingBatch) return;
      setIsProcessingBatch(true);

      const processItem = async (item: QueueItem) => {
          try {
              setBatchQueue(prev => prev.map(i => i.id === item.id ? { ...i, status: 'processing' } : i));

              // 1. Parse ALL files for this candidate
              let combinedText = "";
              for (const file of item.files) {
                  const text = await parseFile(file);
                  combinedText += `\n\n=== CONTEÚDO DO ARQUIVO: ${file.name} ===\n${text}`;
              }

              // 2. AI Analysis
              // We pass combined text as both CV and Transcript context to let AI figure it out,
              // or we could try to heuristically separate them. 
              // For robustness, we pass the combined blob to the "CV" field and a note in "Transcript".
              const aiResult = await runPhase2Interview(
                  item.candidateName,
                  combinedText, 
                  "Analise o texto combinado acima que pode conter CV e Transcrição da Entrevista.",
                  "Processamento em Lote - Múltiplos Arquivos"
              );

              // 3. Auto-save
              onCandidateEvaluated(
                  aiResult,
                  combinedText,
                  `Importação em Lote (${item.files.length} arquivos): ${aiResult.interviewerConclusion}`
              );

              setBatchQueue(prev => prev.map(i => i.id === item.id ? { ...i, status: 'success', result: aiResult } : i));

          } catch (error: any) {
              console.error(error);
              setBatchQueue(prev => prev.map(i => i.id === item.id ? { ...i, status: 'error', errorMsg: "Falha na análise." } : i));
          }
      };

      const pending = batchQueue.filter(i => i.status === 'pending' || i.status === 'error');
      
      for (const item of pending) {
          await processItem(item);
      }

      setIsProcessingBatch(false);
  };

  const removeQueueItem = (id: string) => {
      setBatchQueue(prev => prev.filter(i => i.id !== id));
  };

  const clearQueue = () => {
      setBatchQueue([]);
  };

  return (
    <div className="max-w-6xl mx-auto p-6 bg-white rounded-xl shadow-sm border border-gray-100">
      {showGmailPicker && (
          <GmailPicker 
            onSelect={(text) => setInterviewTranscript(text)} 
            onClose={() => setShowGmailPicker(false)} 
          />
      )}
      {showDrivePicker && (
          <DrivePicker
             onSelect={(text) => {
                 if (showDrivePicker === 'cv') setCvText(text);
                 else setInterviewTranscript(text);
             }}
             onClose={() => setShowDrivePicker(null)}
          />
      )}

      {/* Header & Batch Actions */}
      <div className="mb-8 flex flex-col md:flex-row md:justify-between md:items-end border-b border-gray-100 pb-6 gap-4">
        <div>
            <h2 className="text-2xl font-bold text-gray-800 mb-1">Fase 2: Entrevista & Avaliação</h2>
            <p className="text-gray-500 text-sm">
                Analise candidatos individualmente ou use o <span className="text-indigo-600 font-semibold">Acelerador em Lote</span> para processar múltiplos arquivos.
            </p>
        </div>
        
        <div className="flex gap-3">
            {result ? (
                <button onClick={handleReset} className="px-4 py-2 border border-gray-300 text-gray-600 rounded-lg hover:bg-gray-50 text-sm font-medium flex items-center">
                    <X className="w-4 h-4 mr-2"/> Cancelar Edição
                </button>
            ) : (
                <>
                    <input 
                        type="file" 
                        multiple 
                        accept=".pdf,.docx,.txt" 
                        ref={batchInputRef} 
                        className="hidden"
                        onChange={handleBatchSelect}
                    />
                    <button 
                        onClick={() => batchInputRef.current?.click()}
                        className="flex items-center px-4 py-2 bg-indigo-50 text-indigo-700 border border-indigo-200 rounded-lg hover:bg-indigo-100 transition-colors text-sm font-bold shadow-sm"
                    >
                        <Upload className="w-4 h-4 mr-2" />
                        Batch Upload (Múltiplos)
                    </button>
                </>
            )}
        </div>
      </div>

      {/* --- BATCH QUEUE PANEL --- */}
      {batchQueue.length > 0 && !result && (
          <div className="mb-10 bg-slate-50 rounded-xl border border-slate-200 overflow-hidden">
              <div className="p-4 bg-slate-100 border-b border-slate-200 flex justify-between items-center">
                  <h3 className="font-bold text-slate-700 flex items-center">
                      <FileStack className="w-4 h-4 mr-2" />
                      Fila de Processamento ({batchQueue.filter(i => i.status === 'success').length}/{batchQueue.length})
                  </h3>
                  <div className="flex gap-2">
                      <button 
                        onClick={clearQueue}
                        className="text-xs text-slate-500 hover:text-red-600 px-3 py-1"
                      >
                          Limpar
                      </button>
                      <button 
                        onClick={processBatchQueue}
                        disabled={isProcessingBatch || !batchQueue.some(i => i.status === 'pending' || i.status === 'error')}
                        className="flex items-center px-4 py-1.5 bg-indigo-600 text-white rounded-md text-sm font-bold hover:bg-indigo-700 disabled:opacity-50 shadow-sm"
                      >
                          {isProcessingBatch ? <Loader2 className="w-4 h-4 mr-2 animate-spin"/> : <Play className="w-4 h-4 mr-2"/>}
                          {isProcessingBatch ? "Processando..." : "Iniciar Fila"}
                      </button>
                  </div>
              </div>
              
              <div className="max-h-64 overflow-y-auto p-2 grid grid-cols-1 gap-2">
                  {batchQueue.map(item => (
                      <div key={item.id} className="bg-white p-3 rounded border border-slate-200 flex items-center justify-between shadow-sm animate-fade-in">
                          <div className="flex items-center gap-3 overflow-hidden">
                              <div className={`w-2 h-8 rounded-full shrink-0 
                                  ${item.status === 'pending' ? 'bg-gray-300' : 
                                    item.status === 'processing' ? 'bg-blue-500 animate-pulse' : 
                                    item.status === 'success' ? 'bg-green-500' : 'bg-red-500'}`
                              }></div>
                              <div className="min-w-0 flex-1">
                                  <div className="flex items-center justify-between">
                                      <p className="text-sm font-bold text-gray-800 truncate">{item.candidateName}</p>
                                      <span className="text-[10px] bg-slate-100 text-slate-600 px-2 py-0.5 rounded-full border border-slate-200">
                                          {item.files.length} arquivo{item.files.length !== 1 ? 's' : ''}
                                      </span>
                                  </div>
                                  <p className="text-xs text-gray-400 truncate mt-0.5">
                                      {item.files.map(f => f.name).join(', ')}
                                  </p>
                                  <p className="text-xs text-indigo-500 mt-1 font-medium">
                                      {item.status === 'pending' && "Aguardando..."}
                                      {item.status === 'processing' && "Lendo e Analisando..."}
                                      {item.status === 'success' && "Processado e Salvo"}
                                      {item.status === 'error' && item.errorMsg}
                                  </p>
                              </div>
                          </div>
                          
                          {item.status !== 'processing' && (
                              <button 
                                onClick={() => removeQueueItem(item.id)}
                                className="text-gray-400 hover:text-red-500 p-1 ml-2"
                              >
                                  <Trash2 className="w-4 h-4" />
                              </button>
                          )}
                      </div>
                  ))}
              </div>
              <div className="px-4 py-2 bg-indigo-50/50 text-xs text-indigo-700 border-t border-slate-200">
                  * O sistema agrupou os arquivos automaticamente pelo nome. Certifique-se de que os arquivos de um mesmo candidato tenham nomes similares (ex: "Paulo CV.pdf" e "Paulo Transcrição.pdf").
              </div>
          </div>
      )}

      {/* --- SINGLE CANDIDATE FORM --- */}
      {!result ? (
        <div className={`space-y-6 ${batchQueue.length > 0 ? 'opacity-50 grayscale pointer-events-none blur-[1px]' : ''}`}>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Nome do Candidato</label>
                    <input
                        type="text"
                        value={candidateName}
                        onChange={(e) => setCandidateName(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-shadow"
                        placeholder="Ex: Ana Souza"
                    />
                </div>
                <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">Notas do Consultor (Contexto Extra)</label>
                    <input
                        type="text"
                        value={consultantNotes}
                        onChange={(e) => setConsultantNotes(e.target.value)}
                        placeholder="Ex: Candidata indicada pelo CEO, foi tech lead na Amazon..."
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:outline-none transition-shadow"
                    />
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="block text-sm font-semibold text-gray-700">Currículo (Texto/PDF)</label>
                        <div className="flex gap-2">
                            <button 
                                onClick={() => setShowDrivePicker('cv')} 
                                className="text-xs flex items-center bg-green-50 text-green-700 hover:bg-green-100 px-2 py-1 rounded border border-green-200 transition-colors"
                            >
                                <HardDrive className="w-3 h-3 mr-1" /> Drive
                            </button>
                            <button 
                                onClick={() => cvInputRef.current?.click()} 
                                className="text-xs flex items-center bg-blue-50 text-blue-700 hover:bg-blue-100 px-2 py-1 rounded border border-blue-200 transition-colors"
                                disabled={parsingCv}
                            >
                                {parsingCv ? <Loader2 className="animate-spin w-3 h-3 mr-1"/> : <Upload className="w-3 h-3 mr-1" />}
                                Upload
                            </button>
                        </div>
                        <input 
                            type="file" 
                            ref={cvInputRef} 
                            className="hidden" 
                            accept=".txt,.md,.pdf,.docx"
                            onChange={(e) => handleFileUpload(e, 'cv')}
                        />
                    </div>
                    <textarea
                        value={cvText}
                        onChange={(e) => setCvText(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg h-40 focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs font-mono"
                        placeholder="Cole o texto ou faça upload..."
                    />
                </div>

                <div>
                    <div className="flex justify-between items-center mb-2">
                        <label className="block text-sm font-semibold text-gray-700">Transcrição da Entrevista</label>
                        <div className="flex gap-2">
                            <button 
                                onClick={() => setShowDrivePicker('transcript')} 
                                className="text-xs flex items-center bg-green-50 text-green-700 hover:bg-green-100 px-2 py-1 rounded border border-green-200 transition-colors"
                            >
                                <HardDrive className="w-3 h-3 mr-1" /> Drive
                            </button>
                            <button 
                                onClick={() => setShowGmailPicker(true)}
                                className="text-xs flex items-center bg-red-50 text-red-700 hover:bg-red-100 px-2 py-1 rounded border border-red-200 transition-colors"
                            >
                                <Mail className="w-3 h-3 mr-1" /> Gmail
                            </button>
                            <button 
                                onClick={() => transcriptInputRef.current?.click()} 
                                className="text-xs flex items-center bg-blue-50 text-blue-700 hover:bg-blue-100 px-2 py-1 rounded border border-blue-200 transition-colors"
                                disabled={parsingTranscript}
                            >
                                {parsingTranscript ? <Loader2 className="animate-spin w-3 h-3 mr-1"/> : <Upload className="w-3 h-3 mr-1" />}
                                Upload
                            </button>
                        </div>
                        <input 
                            type="file" 
                            ref={transcriptInputRef} 
                            className="hidden" 
                            accept=".txt,.md,.pdf,.docx"
                            onChange={(e) => handleFileUpload(e, 'transcript')}
                        />
                    </div>
                    <textarea
                        value={interviewTranscript}
                        onChange={(e) => setInterviewTranscript(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg h-40 focus:ring-2 focus:ring-blue-500 focus:outline-none text-xs font-mono"
                        placeholder="Cole o texto ou faça upload..."
                    />
                </div>
            </div>

            <button
            onClick={handleProcess}
            disabled={loading || !candidateName || !cvText}
            className="flex items-center justify-center w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white font-bold py-4 px-6 rounded-lg transition-all shadow-md hover:shadow-lg disabled:opacity-50 disabled:cursor-not-allowed transform hover:-translate-y-0.5"
            >
            {loading ? <Loader2 className="animate-spin mr-2" /> : "Analisar Candidato com IA"}
            </button>
        </div>
      ) : (
          <div className="animate-fade-in">
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6 flex items-start">
                  <Edit2 className="w-5 h-5 text-yellow-600 mr-3 mt-0.5 shrink-0" />
                  <div>
                      <h4 className="font-bold text-yellow-800 text-sm">Revisão Humana Obrigatória</h4>
                      <p className="text-yellow-700 text-xs mt-1">
                          A IA gerou a análise abaixo. Por favor, revise e edite quaisquer imprecisões antes de salvar. 
                          Isso garante a qualidade dos dados para a Shortlist e a Decisão Final.
                      </p>
                  </div>
              </div>

              <div className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-sm">
                  <div className="p-6 bg-gray-50 border-b border-gray-200 flex justify-between items-center">
                       <h3 className="text-lg font-bold text-gray-800 flex items-center">
                           <input 
                                className="bg-transparent border-none focus:ring-0 font-bold text-gray-800 p-0 text-lg w-full"
                                value={editedResult?.candidateName}
                                onChange={(e) => updateField('candidateName', e.target.value)}
                           />
                       </h3>
                       <div className="flex items-center gap-2">
                           <span className="text-sm text-gray-500 mr-2">Posição Atual:</span>
                           <input 
                                className="bg-white border border-gray-300 rounded px-2 py-1 text-sm text-gray-700 focus:ring-2 focus:ring-blue-500 outline-none w-64"
                                value={editedResult?.currentPosition}
                                onChange={(e) => updateField('currentPosition', e.target.value)}
                           />
                       </div>
                  </div>

                  <div className="p-6 space-y-6">
                        <EditableSection 
                            title="Conclusão do Entrevistador" 
                            value={editedResult?.interviewerConclusion || ''}
                            onChange={(v) => updateField('interviewerConclusion', v)}
                            rows={3}
                        />
                        <EditableSection 
                            title="Principais Projetos (Método STAR)" 
                            value={editedResult?.mainProjects || ''}
                            onChange={(v) => updateField('mainProjects', v)}
                            rows={4}
                        />
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                             <EditableSection 
                                title="Core Skills & Competências" 
                                value={editedResult?.coreSkills || ''}
                                onChange={(v) => updateField('coreSkills', v)}
                                rows={4}
                            />
                             <EditableSection 
                                title="Experiência Profissional (Resumo)" 
                                value={editedResult?.experience || ''}
                                onChange={(v) => updateField('experience', v)}
                                rows={4}
                            />
                        </div>
                        
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 p-4 bg-gray-50 rounded-lg border border-gray-200">
                             <EditableSection 
                                title="Motivação para Mudança" 
                                value={editedResult?.motivation || ''}
                                onChange={(v) => updateField('motivation', v)}
                                rows={2}
                            />
                            <EditableSection 
                                title="Pacote de Remuneração Atual/Pretensão" 
                                value={editedResult?.remuneration || ''}
                                onChange={(v) => updateField('remuneration', v)}
                                rows={2}
                            />
                            <EditableSection 
                                title="Mobilidade / Híbrido" 
                                value={editedResult?.mobility || ''}
                                onChange={(v) => updateField('mobility', v)}
                                rows={1}
                            />
                            <EditableSection 
                                title="Nível de Inglês" 
                                value={editedResult?.englishLevel || ''}
                                onChange={(v) => updateField('englishLevel', v)}
                                rows={1}
                            />
                        </div>

                        <EditableSection 
                            title="Comunicação & Soft Skills" 
                            value={editedResult?.communication || ''}
                            onChange={(v) => updateField('communication', v)}
                            rows={2}
                        />

                        <div className="bg-blue-50 p-4 rounded-lg border border-blue-100">
                             <label className="block text-xs font-bold text-blue-800 uppercase tracking-wider mb-2">Recomendação Final</label>
                             <select 
                                value={editedResult?.recommendation}
                                onChange={(e) => updateField('recommendation', e.target.value)}
                                className="w-full p-2 border border-blue-200 rounded text-blue-900 bg-white focus:ring-2 focus:ring-blue-500 outline-none font-semibold"
                             >
                                 <option value="Aprovado / Avançar">Aprovado / Avançar</option>
                                 <option value="Stand-by / Reserva">Stand-by / Reserva</option>
                                 <option value="Reprovado / Tech Fit">Reprovado / Tech Fit</option>
                                 <option value="Reprovado / Cultural Fit">Reprovado / Cultural Fit</option>
                             </select>
                        </div>
                  </div>
                  
                  <div className="bg-gray-50 p-6 border-t border-gray-200 flex justify-end gap-3 sticky bottom-0">
                      <button 
                        onClick={() => setResult(null)}
                        className="px-6 py-2.5 rounded-lg border border-gray-300 text-gray-700 font-medium hover:bg-gray-100 transition-colors"
                      >
                          Descartar
                      </button>
                      <button 
                        onClick={handleSaveToPipeline}
                        className="px-6 py-2.5 rounded-lg bg-green-600 text-white font-bold hover:bg-green-700 shadow-md flex items-center transition-transform hover:-translate-y-0.5"
                      >
                          <Check className="w-5 h-5 mr-2" />
                          Confirmar Validação
                      </button>
                  </div>
              </div>
          </div>
      )}
    </div>
  );
};

const EditableSection: React.FC<{title: string, value: string, onChange: (val: string) => void, rows?: number}> = ({title, value, onChange, rows = 3}) => (
    <div className="w-full">
        <label className="block text-xs font-bold text-gray-500 uppercase tracking-wider mb-1.5">{title}</label>
        <textarea 
            value={value}
            onChange={(e) => onChange(e.target.value)}
            rows={rows}
            className="w-full p-2.5 border border-gray-300 rounded-lg text-sm text-gray-800 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition-shadow bg-white hover:bg-gray-50 focus:bg-white resize-none"
        />
    </div>
)

export default Phase2Interview;