import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, X, Send, Sparkles, Minimize2, Maximize2, Bot, Loader2 } from 'lucide-react';
import { Phase1Result, Phase2Result, Phase3Result, Phase4Result } from '../types';
import { createChatSession, sendMessageToAssistant, ChatMessage } from '../services/chatService';
import { Chat, Content } from "@google/genai";

interface Props {
  appState: {
    phase1Data: Phase1Result | null;
    candidates: { name: string; fullPhase2: Phase2Result }[];
    shortlist: Phase3Result[];
    phase4Result: Phase4Result | null;
  };
}

const GlobalChatAssistant: React.FC<Props> = ({ appState }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    { role: 'model', text: 'Olá! Sou o assistente Evermonte. Posso ajudar a analisar os candidatos, comparar perfis ou tirar dúvidas sobre o processo. O que deseja saber?' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [chatInstance, setChatInstance] = useState<Chat | null>(null);
  
  // Ref to keep track of messages for history without triggering useEffect on message update
  const messagesRef = useRef<ChatMessage[]>(messages);

  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Sync ref with state
  useEffect(() => {
    messagesRef.current = messages;
  }, [messages]);

  // Re-create chat session whenever appState changes (Context Injection)
  // This ensures the AI always knows about the latest Phase 1/2/3/4 data
  useEffect(() => {
    // We only recreate if we have at least opened it once or it is open
    // This optimization avoids creating chats in background if user never uses it, 
    // BUT we must ensure that if they open it later, it has latest data.
    // The easiest way is to just create it if isOpen is true, or if it was already created.
    if (isOpen) {
        // Map current messages to Google GenAI History format
        // We skip the first artificial greeting message if strictly needed, but let's keep flow natural.
        // Google API expects alternate turns usually, starting with user? 
        // Actually, 'history' can contain model turns.
        // We filter out the very first "Olá" if it was hardcoded (which it is), 
        // because the model wouldn't have it in its internal memory from a previous session if we are starting fresh.
        // However, we want the model to know it said that.
        
        const history: Content[] = messagesRef.current.map(m => ({
            role: m.role,
            parts: [{ text: m.text }]
        }));

        const chat = createChatSession(
            appState.phase1Data,
            appState.candidates,
            appState.shortlist,
            appState.phase4Result,
            history
        );
        setChatInstance(chat);
    }
  }, [appState, isOpen]); 

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isOpen]);

  const handleSend = async () => {
    if (!input.trim()) return;

    // Use current instance or wait for effect? 
    // If input matches, we assume instance is ready or will be ready.
    // However, if appState just changed, effect might run after.
    // In React 18+, batching might happen.
    // To be safe, we guard against null, but the useEffect [isOpen] ensures it's created.
    
    const userMsg = input;
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMsg }]);
    setLoading(true);

    try {
        // If chatInstance is null (race condition), we try to create one on the fly with refs
        let activeChat = chatInstance;
        if (!activeChat) {
             const history: Content[] = messagesRef.current.map(m => ({
                role: m.role,
                parts: [{ text: m.text }]
            }));
            activeChat = createChatSession(
                appState.phase1Data,
                appState.candidates,
                appState.shortlist,
                appState.phase4Result,
                history
            );
            setChatInstance(activeChat);
        }

        const responseText = await sendMessageToAssistant(activeChat, userMsg);
        setMessages(prev => [...prev, { role: 'model', text: responseText }]);
    } catch (e) {
        setMessages(prev => [...prev, { role: 'model', text: "Erro de conexão com a IA." }]);
    } finally {
        setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSend();
    }
  };

  const suggestions = [
    "Resuma a reunião de alinhamento",
    "Compare os candidatos finalistas",
    "Quais os riscos do Candidato 1?",
    "Quem tem melhor fit cultural?"
  ];

  const handleSuggestionClick = (text: string) => {
      setInput(text);
  };

  if (!isOpen) {
    return (
      <button
        onClick={() => setIsOpen(true)}
        className="fixed bottom-6 right-6 bg-slate-900 hover:bg-slate-800 text-white p-4 rounded-full shadow-2xl transition-all hover:scale-110 z-50 flex items-center gap-2 group border border-slate-700"
      >
        <MessageCircle className="w-6 h-6" />
        <span className="max-w-0 overflow-hidden group-hover:max-w-xs transition-all duration-300 ease-in-out whitespace-nowrap font-medium">
            Evermonte AI
        </span>
      </button>
    );
  }

  return (
    <div 
        className={`fixed bottom-6 right-6 bg-white rounded-2xl shadow-2xl border border-gray-200 z-50 flex flex-col transition-all duration-300 overflow-hidden
        ${isMinimized ? 'w-72 h-14' : 'w-96 h-[600px] max-h-[80vh]'}
        `}
    >
      {/* Header */}
      <div className="bg-slate-900 p-4 flex justify-between items-center text-white shrink-0 cursor-pointer" onClick={() => !isMinimized && setIsMinimized(!isMinimized)}>
        <div className="flex items-center gap-2">
            <div className="bg-gradient-to-tr from-blue-500 to-purple-600 p-1.5 rounded-lg">
                <Bot className="w-4 h-4 text-white" />
            </div>
            <div>
                <h3 className="font-bold text-sm leading-tight">Evermonte Assistant</h3>
                <p className="text-[10px] text-slate-400">Powered by Gemini 3.0 Pro</p>
            </div>
        </div>
        <div className="flex gap-2">
            <button 
                onClick={(e) => { e.stopPropagation(); setIsMinimized(!isMinimized); }}
                className="hover:bg-slate-700 p-1 rounded transition-colors"
            >
                {isMinimized ? <Maximize2 className="w-4 h-4" /> : <Minimize2 className="w-4 h-4" />}
            </button>
            <button 
                onClick={(e) => { e.stopPropagation(); setIsOpen(false); setIsMinimized(false); }}
                className="hover:bg-red-500/20 hover:text-red-400 p-1 rounded transition-colors"
            >
                <X className="w-4 h-4" />
            </button>
        </div>
      </div>

      {!isMinimized && (
        <>
            {/* Messages Area */}
            <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-4">
                {messages.map((msg, idx) => (
                    <div key={idx} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div 
                            className={`max-w-[85%] rounded-2xl px-4 py-3 text-sm shadow-sm
                            ${msg.role === 'user' 
                                ? 'bg-blue-600 text-white rounded-br-none' 
                                : 'bg-white text-gray-800 border border-gray-100 rounded-bl-none'
                            }`}
                        >
                            {msg.role === 'model' && (
                                <div className="flex items-center gap-1 mb-1 opacity-50 text-[10px] font-bold uppercase tracking-wider">
                                    <Sparkles className="w-3 h-3" /> AI Analysis
                                </div>
                            )}
                            <div className="whitespace-pre-wrap leading-relaxed markdown-body">
                                {msg.text}
                            </div>
                        </div>
                    </div>
                ))}
                
                {loading && (
                    <div className="flex justify-start">
                        <div className="bg-white text-gray-800 border border-gray-100 rounded-2xl rounded-bl-none px-4 py-3 shadow-sm flex items-center gap-2">
                            <Loader2 className="w-4 h-4 animate-spin text-blue-500" />
                            <span className="text-xs text-gray-400">Analisando dados...</span>
                        </div>
                    </div>
                )}
                <div ref={messagesEndRef} />
            </div>

            {/* Suggestions Chips */}
            {!loading && (
                <div className="px-4 py-2 bg-gray-50 flex gap-2 overflow-x-auto no-scrollbar shrink-0">
                    {suggestions.map((s, i) => (
                        <button 
                            key={i}
                            onClick={() => handleSuggestionClick(s)}
                            className="whitespace-nowrap px-3 py-1.5 bg-white border border-gray-200 rounded-full text-xs text-blue-600 hover:bg-blue-50 hover:border-blue-200 transition-colors shadow-sm"
                        >
                            {s}
                        </button>
                    ))}
                </div>
            )}

            {/* Input Area */}
            <div className="p-3 bg-white border-t border-gray-100 shrink-0">
                <div className="flex gap-2">
                    <input
                        type="text"
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={handleKeyDown}
                        placeholder="Pergunte sobre os candidatos..."
                        disabled={loading}
                        className="flex-1 bg-gray-100 border-transparent focus:bg-white focus:border-blue-500 focus:ring-2 focus:ring-blue-200 rounded-xl px-4 py-2 text-sm transition-all outline-none"
                    />
                    <button
                        onClick={handleSend}
                        disabled={loading || !input.trim()}
                        className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed text-white p-2.5 rounded-xl transition-all shadow-md hover:shadow-lg flex items-center justify-center"
                    >
                        <Send className="w-4 h-4" />
                    </button>
                </div>
            </div>
        </>
      )}
    </div>
  );
};

export default GlobalChatAssistant;