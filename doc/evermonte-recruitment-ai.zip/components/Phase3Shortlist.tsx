import React, { useState, useEffect } from 'react';
import { runPhase3Shortlist } from '../services/geminiService';
import { Phase3Result, Phase2Result } from '../types';
import { Loader2, User, AlertCircle, FileText, CheckSquare, Square, Filter, ArrowRight } from 'lucide-react';

interface CandidateData {
    name: string;
    cvText: string;
    interviewReport: string;
    fullPhase2?: Phase2Result; // Optional to maintain compatibility if data is missing, but preferred
}

interface Props {
    candidates: CandidateData[];
    onShortlistFinalized: (results: Phase3Result[]) => void;
}

const Phase3Shortlist: React.FC<Props> = ({ candidates, onShortlistFinalized }) => {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<Phase3Result[]>([]);
  
  // State to track which candidates are selected for the shortlist
  const [selectedCandidates, setSelectedCandidates] = useState<string[]>([]);

  // Initialize selection when candidates prop changes
  useEffect(() => {
      // By default, select all candidates initially to reduce friction, 
      // or allows user to uncheck the ones that didn't pass.
      if (candidates.length > 0 && selectedCandidates.length === 0) {
          setSelectedCandidates(candidates.map(c => c.name));
      }
  }, [candidates.length]);

  const toggleCandidate = (name: string) => {
      setSelectedCandidates(prev => 
          prev.includes(name) 
              ? prev.filter(n => n !== name) 
              : [...prev, name]
      );
  };

  const toggleAll = () => {
      if (selectedCandidates.length === candidates.length) {
          setSelectedCandidates([]);
      } else {
          setSelectedCandidates(candidates.map(c => c.name));
      }
  };

  const handleAnalyze = async () => {
    const candidatesToAnalyze = candidates.filter(c => selectedCandidates.includes(c.name));
    
    if (candidatesToAnalyze.length === 0) {
        alert("Selecione pelo menos um candidato para gerar a shortlist.");
        return;
    }

    setLoading(true);
    try {
      const data = await runPhase3Shortlist(candidatesToAnalyze);
      setResults(data);
      onShortlistFinalized(data);
    } catch (e) {
        console.error(e);
      alert("Error generating shortlist analysis.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-100 flex flex-col h-full">
      <div className="p-6 border-b border-gray-100 shrink-0">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Fase 3: Shortlist</h2>
        <p className="text-gray-500">Selecione os candidatos aprovados na Fase 2 para compor a tabela comparativa.</p>
      </div>

      <div className="p-6 overflow-hidden flex flex-col flex-1">
        {candidates.length === 0 ? (
            <div className="flex flex-col items-center justify-center p-8 bg-gray-50 rounded-lg border border-dashed border-gray-300 text-center h-full">
                <div className="bg-yellow-100 p-3 rounded-full mb-3">
                    <AlertCircle className="w-6 h-6 text-yellow-700" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-1">Nenhum candidato na fila</h3>
                <p className="text-gray-500 max-w-sm">
                    Vá para a aba <strong>Fase 2: Entrevistas</strong> e avalie pelo menos um candidato para gerar a shortlist.
                </p>
            </div>
        ) : (
            <div className="flex flex-col h-full">
                {/* Selection Area */}
                <div className="mb-6 shrink-0 space-y-4">
                    <div className="flex items-center justify-between">
                        <h4 className="text-sm font-semibold text-gray-700 flex items-center">
                            <Filter className="w-4 h-4 mr-2 text-blue-500"/>
                            Seleção de Finalistas ({selectedCandidates.length}/{candidates.length})
                        </h4>
                        <button 
                            onClick={toggleAll}
                            className="text-xs text-blue-600 hover:text-blue-800 font-medium"
                        >
                            {selectedCandidates.length === candidates.length ? "Desmarcar Todos" : "Marcar Todos"}
                        </button>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-60 overflow-y-auto p-1">
                        {candidates.map((c, idx) => {
                            const isSelected = selectedCandidates.includes(c.name);
                            const recommendation = c.fullPhase2?.recommendation || "N/A";
                            const isRecommended = recommendation.toLowerCase().includes('aprovado') || recommendation.toLowerCase().includes('avançar');
                            
                            return (
                                <div 
                                    key={idx} 
                                    onClick={() => toggleCandidate(c.name)}
                                    className={`
                                        cursor-pointer relative p-3 rounded-lg border transition-all duration-200 group
                                        ${isSelected 
                                            ? 'bg-blue-50 border-blue-200 ring-1 ring-blue-300' 
                                            : 'bg-white border-gray-200 hover:border-gray-300 hover:shadow-sm'}
                                    `}
                                >
                                    <div className="flex items-start gap-3">
                                        <div className={`mt-1 ${isSelected ? 'text-blue-600' : 'text-gray-300 group-hover:text-gray-400'}`}>
                                            {isSelected ? <CheckSquare className="w-5 h-5"/> : <Square className="w-5 h-5"/>}
                                        </div>
                                        <div className="flex-1 min-w-0">
                                            <div className="font-semibold text-gray-800 text-sm truncate">{c.name}</div>
                                            <div className="text-xs text-gray-500 mt-0.5 line-clamp-1">
                                                {c.fullPhase2?.currentPosition || 'Posição não informada'}
                                            </div>
                                            <div className="mt-2 flex items-center justify-between">
                                                <span className={`text-[10px] px-1.5 py-0.5 rounded font-medium truncate max-w-[120px] ${isRecommended ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-600'}`}>
                                                    {recommendation}
                                                </span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            );
                        })}
                    </div>

                    <button
                        onClick={handleAnalyze}
                        disabled={loading || selectedCandidates.length === 0}
                        className="flex items-center justify-center w-full md:w-auto bg-indigo-600 hover:bg-indigo-700 text-white font-semibold py-2.5 px-6 rounded-lg transition-colors disabled:opacity-50 shadow-sm"
                    >
                        {loading ? (
                            <>
                                <Loader2 className="animate-spin mr-2 w-4 h-4" />
                                Processando IA...
                            </>
                        ) : (
                            <>
                                Gerar Análise Comparativa
                                <span className="ml-2 bg-indigo-500 px-2 py-0.5 rounded text-xs">
                                    {selectedCandidates.length}
                                </span>
                                <ArrowRight className="ml-2 w-4 h-4 opacity-80" />
                            </>
                        )}
                    </button>
                </div>

                {/* Results Table */}
                {results.length > 0 && (
                    <div className="flex-1 flex flex-col min-h-0 border-t border-gray-100 pt-6 animate-fade-in">
                        <div className="flex items-center justify-between mb-3 shrink-0">
                            <h3 className="text-lg font-bold text-gray-800 flex items-center">
                                <FileText className="w-5 h-5 mr-2 text-indigo-600"/>
                                Shortlist Gerada
                            </h3>
                            <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
                                * Role horizontalmente para ver todas as colunas
                            </span>
                        </div>
                        
                        <div className="overflow-auto border border-gray-200 rounded-lg shadow-sm flex-1 custom-scrollbar bg-white">
                            <table className="min-w-max divide-y divide-gray-200 text-xs">
                                <thead className="bg-gray-50 sticky top-0 z-10 shadow-sm">
                                    <tr>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200">SHORTLIST</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[150px]">CANDIDATO</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200">IDADE</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[150px]">POSIÇÃO ATUAL</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[120px]">LOCALIDADE</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[250px]">HISTÓRICO ACADÊMICO</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[250px]">EXPERIÊNCIA PROFISSIONAL</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[400px]">PRINCIPAIS PROJETOS</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[150px]">REMUNERAÇÃO</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider border-r border-gray-200 min-w-[250px]">CORE SKILLS</th>
                                        <th scope="col" className="px-3 py-3 text-left font-bold text-gray-600 uppercase tracking-wider min-w-[250px]">MOTIVAÇÕES</th>
                                    </tr>
                                </thead>
                                <tbody className="bg-white divide-y divide-gray-200">
                                    {results.map((r, idx) => (
                                        <tr key={idx} className="hover:bg-gray-50 transition-colors">
                                            <td className="px-3 py-4 whitespace-nowrap border-r border-gray-200 font-bold text-indigo-900 bg-indigo-50/30">
                                                {r.shortlistId}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 font-bold text-gray-900">
                                                {r.candidateName}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-center">
                                                {r.age}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 font-medium text-gray-700">
                                                {r.currentPosition}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-gray-600">
                                                {r.location}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-gray-600 whitespace-pre-wrap">
                                                {r.academicHistory}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-gray-600 whitespace-pre-wrap">
                                                {r.professionalExperience}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-gray-600 text-[11px] leading-relaxed whitespace-pre-wrap bg-gray-50/50">
                                                {r.mainProjects}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-gray-600 font-medium">
                                                {r.remunerationPackage}
                                            </td>
                                            <td className="px-3 py-4 border-r border-gray-200 text-gray-600 whitespace-pre-wrap">
                                                {r.coreSkills}
                                            </td>
                                            <td className="px-3 py-4 text-gray-600 whitespace-pre-wrap">
                                                {r.motivations}
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}
            </div>
        )}
      </div>
    </div>
  );
};

export default Phase3Shortlist;