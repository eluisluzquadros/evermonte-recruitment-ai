export enum Phase {
  ALIGNMENT = 'ALIGNMENT',
  INTERVIEW = 'INTERVIEW',
  SHORTLIST = 'SHORTLIST',
  DECISION = 'DECISION'
}

export interface Phase1Result {
  companyName: string;
  structure: string;
  sectorAndCompetitors: string;
  jobDetails: string;
  idealCoreSkills: string[];
}

export interface Phase2Result {
  candidateName: string;
  currentPosition: string; // Added field
  interviewerConclusion: string;
  experience: string;
  mainProjects: string;
  motivation: string;
  mobility: string;
  englishLevel: string;
  remuneration: string;
  communication: string;
  coreSkills: string;
  recommendation: string;
}

export interface Phase3Result {
  shortlistId: string; // Coluna "SHORTLIST" (ex: Candidato 1)
  candidateName: string; // Coluna "CANDIDATO"
  age: string; // Coluna "IDADE"
  currentPosition: string; // Coluna "POSIÇÃO ATUAL"
  location: string; // Coluna "LOCALIDADE"
  academicHistory: string; // Coluna "HISTÓRICO ACADÊMICO"
  professionalExperience: string; // Coluna "EXPERIÊNCIA PROFISSIONAL"
  mainProjects: string; // Coluna "PRINCIPAIS PROJETOS DA CARREIRA"
  remunerationPackage: string; // Coluna "PACOTE DE REMUNERAÇÃO ATUAL"
  coreSkills: string; // Coluna "CORE SKILLS"
  motivations: string; // Coluna "MOTIVAÇÕES"
}

export interface Phase4CandidateDecision {
  shortlistId: string; // "Candidato 1"
  candidateName: string; // "Nome"
  executiveSummary: string; // "SUMÁRIO EXECUTIVO"
  decisionScenario: string; // "O CENÁRIO DE DECISÃO"
  whyDecision: string; // "O PORQUÊ DO CENÁRIO DE DECISÃO"
}

export interface Phase4Result {
  introduction: string; // Coluna "INTRODUÇÃO" (Célula mesclada)
  candidates: Phase4CandidateDecision[];
}