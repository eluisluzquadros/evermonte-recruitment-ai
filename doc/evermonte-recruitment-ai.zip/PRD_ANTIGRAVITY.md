# PRD: Project Antigravity (Evermonte Next Gen)

**Versão:** 1.3
**Status:** Fase 3 (Dados & Escala)
**Filosofia:** "Recruitment at the Speed of Thought"

---

## 1. Visão do Produto & Filosofia Antigravity
O objetivo do **Project Antigravity** é remover a "gravidade" (atrito, peso operacional, lentidão) do processo de recrutamento. A plataforma deixa de ser um repositório de dados para ser um **exoesqueleto cognitivo** para o recrutador, agora totalmente integrado ao ecossistema Google Workspace.

## 2. Status dos Pilares de Transformação

### Pilar 1: Frictionless Integration (Concluído ✅)
*   **Meta:** Eliminar o "Alt-Tab" entre sistemas.
*   **Status:** Implementado. O sistema agora busca arquivos diretamente do Drive e e-mails do Gmail. O login único (SSO) removeu a barreira de entrada.

### Pilar 2: Cognitive Upgrade (Concluído ✅)
*   **Meta:** Aumentar a capacidade de raciocínio da IA.
*   **Status:** Migração completa para `gemini-3-pro-preview`. O sistema agora realiza "Deep Research" real e análises complexas de personalidade na Fase 4.

### Pilar 3: Holographic Insights / Shadow Recruiter (Concluído ✅)
*   **Meta:** A IA atua proativamente.
*   **Status:** Implementado no Dashboard Kanban com Cards de "Insights Proativos" e no Chatbot Global com contexto total da aplicação.

### Pilar 4: Zero-Gravity Data (Próximo Foco 🎯)
*   **Problema:** Risco de perda de dados se a aba fechar e dificuldade de análise macro.
*   **Solução:** Implementação de persistência local robusta, Exportação/Importação de Estado (Backup) e Exportação para BI (Excel).
*   **Prioridade:** Máxima (Sprint Atual).

### Pilar 5: Batch Particle Accelerator (Próximo Foco 🎯)
*   **Problema:** Processar 50 currículos um a um é lento.
*   **Solução:** Upload em lote na Fase 2 com fila de processamento inteligente.
*   **Prioridade:** Alta.

---

## 3. Especificações Funcionais (Sprint Atual: Dados & Persistência)

### 3.1. Engine de Persistência (Local & Cloud)
*   **Requisito:** Criar mecanismo de *Auto-Save* no `localStorage` para todo o `AppState`.
*   **Feature:** Botão "Salvar Processo" (baixa um JSON encriptado) e "Carregar Processo" para permitir portabilidade entre máquinas sem backend complexo.
*   **Feature:** "Exportar para BI" (Excel estruturado com abas separadas para análise de dados no PowerBI/Looker).

### 3.2. Batch Upload na Fase 2
*   **Requisito:** Permitir seleção múltipla de arquivos (CVs) no input.
*   **Comportamento:** O sistema deve ler todos os arquivos, colocá-los em uma lista de espera visual e processá-los sequencialmente (ou em paralelo limitado) pela IA, criando "slots" de candidatos pré-preenchidos para validação humana.

---

## 4. Arquitetura Atualizada

*   **Core:** React 19.
*   **Auth:** Google OAuth2 (Centralizado em `authService.ts`).
*   **Data Layer:** `services/driveService.ts` e `services/gmailService.ts` conversando diretamente com Google APIs.
*   **AI Layer:** Agentes especializados (`geminiService.ts`) orquestrados por fases (`gemini-3-pro-preview`).
*   **RAG:** Chatbot Global com injeção dinâmica de contexto (`chatService.ts`).

---

## 5. Definition of Done (Próxima Entrega)
O ciclo atual será concluído quando:
1.  O usuário puder arrastar 20 currículos para a Fase 2 e ver o sistema processar todos.
2.  O usuário puder clicar em "Exportar Excel" e receber uma planilha pronta para análise de dados.
3.  O usuário puder fechar o navegador, voltar amanhã e continuar exatamente de onde parou.

> *"Aspirations become capabilities when friction is removed."*